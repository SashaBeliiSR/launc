// 
// Decompiled by Procyon v0.6.0
// 

package paulscode.sound.codecs;

import paulscode.sound.SoundBuffer;
import java.net.UnknownServiceException;
import java.io.IOException;
import paulscode.sound.SoundSystemConfig;
import paulscode.sound.SoundSystemLogger;
import com.jcraft.jorbis.Info;
import com.jcraft.jorbis.Comment;
import com.jcraft.jorbis.Block;
import com.jcraft.jorbis.DspState;
import com.jcraft.jogg.SyncState;
import com.jcraft.jogg.StreamState;
import com.jcraft.jogg.Page;
import com.jcraft.jogg.Packet;
import javax.sound.sampled.AudioFormat;
import java.io.InputStream;
import java.net.URLConnection;
import java.net.URL;
import paulscode.sound.ICodec;

public class CodecJOrbis implements ICodec
{
    private static final boolean GET;
    private static final boolean SET;
    private static final boolean XXX;
    protected URL url;
    protected URLConnection urlConnection;
    private InputStream inputStream;
    private AudioFormat audioFormat;
    private boolean endOfStream;
    private boolean initialized;
    private byte[] buffer;
    private int bufferSize;
    private int count;
    private int index;
    private int convertedBufferSize;
    private float[][][] pcmInfo;
    private int[] pcmIndex;
    private Packet joggPacket;
    private Page joggPage;
    private StreamState joggStreamState;
    private SyncState joggSyncState;
    private DspState jorbisDspState;
    private Block jorbisBlock;
    private Comment jorbisComment;
    private Info jorbisInfo;
    private SoundSystemLogger logger;
    
    public CodecJOrbis() {
        this.urlConnection = null;
        this.endOfStream = false;
        this.initialized = false;
        this.buffer = null;
        this.count = 0;
        this.index = 0;
        this.joggPacket = new Packet();
        this.joggPage = new Page();
        this.joggStreamState = new StreamState();
        this.joggSyncState = new SyncState();
        this.jorbisDspState = new DspState();
        this.jorbisBlock = new Block(this.jorbisDspState);
        this.jorbisComment = new Comment();
        this.jorbisInfo = new Info();
        this.logger = SoundSystemConfig.getLogger();
    }
    
    public void reverseByteOrder(final boolean b) {
    }
    
    public boolean initialize(final URL url) {
        this.initialized(true, false);
        if (this.joggStreamState != null) {
            this.joggStreamState.clear();
        }
        if (this.jorbisBlock != null) {
            this.jorbisBlock.clear();
        }
        if (this.jorbisDspState != null) {
            this.jorbisDspState.clear();
        }
        if (this.jorbisInfo != null) {
            this.jorbisInfo.clear();
        }
        if (this.joggSyncState != null) {
            this.joggSyncState.clear();
        }
        if (this.inputStream != null) {
            try {
                this.inputStream.close();
            }
            catch (final IOException ex) {}
        }
        this.url = url;
        this.bufferSize = SoundSystemConfig.getStreamingBufferSize() / 2;
        this.buffer = null;
        this.count = 0;
        this.index = 0;
        this.joggStreamState = new StreamState();
        this.jorbisBlock = new Block(this.jorbisDspState);
        this.jorbisDspState = new DspState();
        this.jorbisInfo = new Info();
        this.joggSyncState = new SyncState();
        try {
            this.urlConnection = url.openConnection();
        }
        catch (final UnknownServiceException ex2) {
            this.errorMessage("Unable to create a UrlConnection in method 'initialize'.");
            this.printStackTrace(ex2);
            this.cleanup();
            return false;
        }
        catch (final IOException ex3) {
            this.errorMessage("Unable to create a UrlConnection in method 'initialize'.");
            this.printStackTrace(ex3);
            this.cleanup();
            return false;
        }
        if (this.urlConnection != null) {
            try {
                this.inputStream = this.openInputStream();
            }
            catch (final IOException ex4) {
                this.errorMessage("Unable to acquire inputstream in method 'initialize'.");
                this.printStackTrace(ex4);
                this.cleanup();
                return false;
            }
        }
        this.endOfStream(true, false);
        this.joggSyncState.init();
        this.joggSyncState.buffer(this.bufferSize);
        this.buffer = this.joggSyncState.data;
        try {
            if (!this.readHeader()) {
                this.errorMessage("Error reading the header");
                return false;
            }
        }
        catch (final IOException ex5) {
            this.errorMessage("Error reading the header");
            return false;
        }
        this.convertedBufferSize = this.bufferSize * 2;
        this.jorbisDspState.synthesis_init(this.jorbisInfo);
        this.jorbisBlock.init(this.jorbisDspState);
        this.audioFormat = new AudioFormat((float)this.jorbisInfo.rate, 16, this.jorbisInfo.channels, true, false);
        this.pcmInfo = new float[1][][];
        this.pcmIndex = new int[this.jorbisInfo.channels];
        this.initialized(true, true);
        return true;
    }
    
    protected InputStream openInputStream() {
        return this.urlConnection.getInputStream();
    }
    
    public boolean initialized() {
        return this.initialized(false, false);
    }
    
    public SoundBuffer read() {
        final byte[] bytes = this.readBytes();
        if (bytes == null) {
            return null;
        }
        return new SoundBuffer(bytes, this.audioFormat);
    }
    
    public SoundBuffer readAll() {
        byte[] array = this.readBytes();
        while (!this.endOfStream(false, false)) {
            array = appendByteArrays(array, this.readBytes());
            if (array != null && array.length >= SoundSystemConfig.getMaxFileSize()) {
                break;
            }
        }
        return new SoundBuffer(array, this.audioFormat);
    }
    
    public boolean endOfStream() {
        return this.endOfStream(false, false);
    }
    
    public void cleanup() {
        this.joggStreamState.clear();
        this.jorbisBlock.clear();
        this.jorbisDspState.clear();
        this.jorbisInfo.clear();
        this.joggSyncState.clear();
        if (this.inputStream != null) {
            try {
                this.inputStream.close();
            }
            catch (final IOException ex) {}
        }
        this.joggStreamState = null;
        this.jorbisBlock = null;
        this.jorbisDspState = null;
        this.jorbisInfo = null;
        this.joggSyncState = null;
        this.inputStream = null;
    }
    
    public AudioFormat getAudioFormat() {
        return this.audioFormat;
    }
    
    private boolean readHeader() {
        this.index = this.joggSyncState.buffer(this.bufferSize);
        int read = this.inputStream.read(this.joggSyncState.data, this.index, this.bufferSize);
        if (read < 0) {
            read = 0;
        }
        this.joggSyncState.wrote(read);
        if (this.joggSyncState.pageout(this.joggPage) != 1) {
            if (read < this.bufferSize) {
                return true;
            }
            this.errorMessage("Ogg header not recognized in method 'readHeader'.");
            return false;
        }
        else {
            this.joggStreamState.init(this.joggPage.serialno());
            this.jorbisInfo.init();
            this.jorbisComment.init();
            if (this.joggStreamState.pagein(this.joggPage) < 0) {
                this.errorMessage("Problem with first Ogg header page in method 'readHeader'.");
                return false;
            }
            if (this.joggStreamState.packetout(this.joggPacket) != 1) {
                this.errorMessage("Problem with first Ogg header packet in method 'readHeader'.");
                return false;
            }
            if (this.jorbisInfo.synthesis_headerin(this.jorbisComment, this.joggPacket) < 0) {
                this.errorMessage("File does not contain Vorbis header in method 'readHeader'.");
                return false;
            }
            int i = 0;
            while (i < 2) {
                while (i < 2) {
                    final int pageout = this.joggSyncState.pageout(this.joggPage);
                    if (pageout == 0) {
                        break;
                    }
                    if (pageout != 1) {
                        continue;
                    }
                    this.joggStreamState.pagein(this.joggPage);
                    while (i < 2) {
                        final int packetout = this.joggStreamState.packetout(this.joggPacket);
                        if (packetout == 0) {
                            break;
                        }
                        if (packetout == -1) {
                            this.errorMessage("Secondary Ogg header corrupt in method 'readHeader'.");
                            return false;
                        }
                        this.jorbisInfo.synthesis_headerin(this.jorbisComment, this.joggPacket);
                        ++i;
                    }
                }
                this.index = this.joggSyncState.buffer(this.bufferSize);
                int read2 = this.inputStream.read(this.joggSyncState.data, this.index, this.bufferSize);
                if (read2 < 0) {
                    read2 = 0;
                }
                if (read2 == 0 && i < 2) {
                    this.errorMessage("End of file reached before finished readingOgg header in method 'readHeader'");
                    return false;
                }
                this.joggSyncState.wrote(read2);
            }
            this.index = this.joggSyncState.buffer(this.bufferSize);
            this.buffer = this.joggSyncState.data;
            return true;
        }
    }
    
    private byte[] readBytes() {
        if (!this.initialized(false, false)) {
            return null;
        }
        if (this.endOfStream(false, false)) {
            return null;
        }
        byte[] appendByteArrays = null;
        switch (this.joggSyncState.pageout(this.joggPage)) {
            case -1:
            case 0: {
                this.endOfStream(true, true);
                break;
            }
            case 1: {
                this.joggStreamState.pagein(this.joggPage);
                if (this.joggPage.granulepos() == 0L) {
                    this.endOfStream(true, true);
                    break;
                }
            Label_0140:
                while (true) {
                    switch (this.joggStreamState.packetout(this.joggPacket)) {
                        case -1:
                        case 0: {
                            break Label_0140;
                        }
                        case 1: {
                            appendByteArrays = appendByteArrays(appendByteArrays, this.decodeCurrentPacket());
                            continue;
                        }
                    }
                }
                if (this.joggPage.eos() != 0) {
                    this.endOfStream(true, true);
                    break;
                }
                break;
            }
        }
        if (!this.endOfStream(false, false)) {
            this.index = this.joggSyncState.buffer(this.bufferSize);
            if (this.index == -1) {
                this.endOfStream(true, true);
            }
            else {
                this.buffer = this.joggSyncState.data;
                try {
                    this.count = this.inputStream.read(this.buffer, this.index, this.bufferSize);
                }
                catch (final Exception ex) {
                    this.printStackTrace(ex);
                    return appendByteArrays;
                }
                this.joggSyncState.wrote(this.count);
                if (this.count == 0) {
                    this.endOfStream(true, true);
                }
            }
        }
        return appendByteArrays;
    }
    
    private byte[] decodeCurrentPacket() {
        final byte[] array = new byte[this.convertedBufferSize];
        if (this.jorbisBlock.synthesis(this.joggPacket) == 0) {
            this.jorbisDspState.synthesis_blockin(this.jorbisBlock);
        }
        final int n = this.convertedBufferSize / (this.jorbisInfo.channels * 2);
        int n2 = 0;
        int synthesis_pcmout;
        while (n2 < this.convertedBufferSize && (synthesis_pcmout = this.jorbisDspState.synthesis_pcmout(this.pcmInfo, this.pcmIndex)) > 0) {
            int n3;
            if (synthesis_pcmout < n) {
                n3 = synthesis_pcmout;
            }
            else {
                n3 = n;
            }
            for (int i = 0; i < this.jorbisInfo.channels; ++i) {
                int n4 = i * 2;
                for (int j = 0; j < n3; ++j) {
                    int n5 = (int)(this.pcmInfo[0][i][this.pcmIndex[i] + j] * 32767.0f);
                    if (n5 > 32767) {
                        n5 = 32767;
                    }
                    if (n5 < -32768) {
                        n5 = -32768;
                    }
                    if (n5 < 0) {
                        n5 |= 0x8000;
                    }
                    array[n2 + n4] = (byte)n5;
                    array[n2 + n4 + 1] = (byte)(n5 >>> 8);
                    n4 += 2 * this.jorbisInfo.channels;
                }
            }
            n2 += n3 * this.jorbisInfo.channels * 2;
            this.jorbisDspState.synthesis_read(n3);
        }
        return trimArray(array, n2);
    }
    
    private synchronized boolean initialized(final boolean b, final boolean initialized) {
        if (b) {
            this.initialized = initialized;
        }
        return this.initialized;
    }
    
    private synchronized boolean endOfStream(final boolean b, final boolean endOfStream) {
        if (b) {
            this.endOfStream = endOfStream;
        }
        return this.endOfStream;
    }
    
    private static byte[] trimArray(final byte[] array, final int n) {
        Object o = null;
        if (array != null && array.length > n) {
            o = new byte[n];
            System.arraycopy(array, 0, o, 0, n);
        }
        return (byte[])o;
    }
    
    private static byte[] appendByteArrays(final byte[] array, final byte[] array2) {
        if (array == null && array2 == null) {
            return null;
        }
        byte[] array3;
        if (array == null) {
            array3 = new byte[array2.length];
            System.arraycopy(array2, 0, array3, 0, array2.length);
        }
        else if (array2 == null) {
            array3 = new byte[array.length];
            System.arraycopy(array, 0, array3, 0, array.length);
        }
        else {
            array3 = new byte[array.length + array2.length];
            System.arraycopy(array, 0, array3, 0, array.length);
            System.arraycopy(array2, 0, array3, array.length, array2.length);
        }
        return array3;
    }
    
    private void errorMessage(final String s) {
        this.logger.errorMessage("CodecJOrbis", s, 0);
    }
    
    private void printStackTrace(final Exception ex) {
        this.logger.printStackTrace(ex, 1);
    }
    
    static {
        SET = true;
        XXX = false;
        GET = false;
    }
}
