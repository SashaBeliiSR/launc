// 
// Decompiled by Procyon v0.6.0
// 

package paulscode.sound;

public class CommandObject
{
    public static final int INITIALIZE;
    public static final int LOAD_SOUND;
    public static final int UNLOAD_SOUND;
    public static final int QUEUE_SOUND;
    public static final int DEQUEUE_SOUND;
    public static final int FADE_OUT;
    public static final int FADE_OUT_IN;
    public static final int CHECK_FADE_VOLUMES;
    public static final int NEW_SOURCE;
    public static final int RAW_DATA_STREAM;
    public static final int QUICK_PLAY;
    public static final int SET_POSITION;
    public static final int SET_VOLUME;
    public static final int SET_PITCH;
    public static final int SET_PRIORITY;
    public static final int SET_LOOPING;
    public static final int SET_ATTENUATION;
    public static final int SET_DIST_OR_ROLL;
    public static final int PLAY;
    public static final int FEED_RAW_AUDIO_DATA;
    public static final int PAUSE;
    public static final int STOP;
    public static final int REWIND;
    public static final int FLUSH;
    public static final int CULL;
    public static final int ACTIVATE;
    public static final int SET_TEMPORARY;
    public static final int REMOVE_SOURCE;
    public static final int MOVE_LISTENER;
    public static final int SET_LISTENER_POSITION;
    public static final int TURN_LISTENER;
    public static final int SET_LISTENER_ANGLE;
    public static final int SET_LISTENER_ORIENTATION;
    public static final int SET_MASTER_VOLUME;
    public static final int NEW_LIBRARY;
    public byte[] buffer;
    public int[] intArgs;
    public float[] floatArgs;
    public long[] longArgs;
    public boolean[] boolArgs;
    public String[] stringArgs;
    public Class[] classArgs;
    public Object[] objectArgs;
    public int Command;
    
    public CommandObject(final int command) {
        this.Command = command;
    }
    
    public CommandObject(final int command, final int n) {
        this.Command = command;
        (this.intArgs = new int[1])[0] = n;
    }
    
    public CommandObject(final int command, final Class clazz) {
        this.Command = command;
        (this.classArgs = new Class[1])[0] = clazz;
    }
    
    public CommandObject(final int command, final float n) {
        this.Command = command;
        (this.floatArgs = new float[1])[0] = n;
    }
    
    public CommandObject(final int command, final String s) {
        this.Command = command;
        (this.stringArgs = new String[1])[0] = s;
    }
    
    public CommandObject(final int command, final Object o) {
        this.Command = command;
        (this.objectArgs = new Object[1])[0] = o;
    }
    
    public CommandObject(final int command, final String s, final Object o) {
        this.Command = command;
        (this.stringArgs = new String[1])[0] = s;
        (this.objectArgs = new Object[1])[0] = o;
    }
    
    public CommandObject(final int command, final String s, final byte[] buffer) {
        this.Command = command;
        (this.stringArgs = new String[1])[0] = s;
        this.buffer = buffer;
    }
    
    public CommandObject(final int command, final String s, final Object o, final long n) {
        this.Command = command;
        (this.stringArgs = new String[1])[0] = s;
        (this.objectArgs = new Object[1])[0] = o;
        (this.longArgs = new long[1])[0] = n;
    }
    
    public CommandObject(final int command, final String s, final Object o, final long n, final long n2) {
        this.Command = command;
        (this.stringArgs = new String[1])[0] = s;
        (this.objectArgs = new Object[1])[0] = o;
        (this.longArgs = new long[2])[0] = n;
        this.longArgs[1] = n2;
    }
    
    public CommandObject(final int command, final String s, final String s2) {
        this.Command = command;
        (this.stringArgs = new String[2])[0] = s;
        this.stringArgs[1] = s2;
    }
    
    public CommandObject(final int command, final String s, final int n) {
        this.Command = command;
        this.intArgs = new int[1];
        this.stringArgs = new String[1];
        this.intArgs[0] = n;
        this.stringArgs[0] = s;
    }
    
    public CommandObject(final int command, final String s, final float n) {
        this.Command = command;
        this.floatArgs = new float[1];
        this.stringArgs = new String[1];
        this.floatArgs[0] = n;
        this.stringArgs[0] = s;
    }
    
    public CommandObject(final int command, final String s, final boolean b) {
        this.Command = command;
        this.boolArgs = new boolean[1];
        this.stringArgs = new String[1];
        this.boolArgs[0] = b;
        this.stringArgs[0] = s;
    }
    
    public CommandObject(final int command, final float n, final float n2, final float n3) {
        this.Command = command;
        (this.floatArgs = new float[3])[0] = n;
        this.floatArgs[1] = n2;
        this.floatArgs[2] = n3;
    }
    
    public CommandObject(final int command, final String s, final float n, final float n2, final float n3) {
        this.Command = command;
        this.floatArgs = new float[3];
        this.stringArgs = new String[1];
        this.floatArgs[0] = n;
        this.floatArgs[1] = n2;
        this.floatArgs[2] = n3;
        this.stringArgs[0] = s;
    }
    
    public CommandObject(final int command, final float n, final float n2, final float n3, final float n4, final float n5, final float n6) {
        this.Command = command;
        (this.floatArgs = new float[6])[0] = n;
        this.floatArgs[1] = n2;
        this.floatArgs[2] = n3;
        this.floatArgs[3] = n4;
        this.floatArgs[4] = n5;
        this.floatArgs[5] = n6;
    }
    
    public CommandObject(final int command, final boolean b, final boolean b2, final boolean b3, final String s, final Object o, final float n, final float n2, final float n3, final int n4, final float n5) {
        this.Command = command;
        this.intArgs = new int[1];
        this.floatArgs = new float[4];
        this.boolArgs = new boolean[3];
        this.stringArgs = new String[1];
        this.objectArgs = new Object[1];
        this.intArgs[0] = n4;
        this.floatArgs[0] = n;
        this.floatArgs[1] = n2;
        this.floatArgs[2] = n3;
        this.floatArgs[3] = n5;
        this.boolArgs[0] = b;
        this.boolArgs[1] = b2;
        this.boolArgs[2] = b3;
        this.stringArgs[0] = s;
        this.objectArgs[0] = o;
    }
    
    public CommandObject(final int command, final boolean b, final boolean b2, final boolean b3, final String s, final Object o, final float n, final float n2, final float n3, final int n4, final float n5, final boolean b4) {
        this.Command = command;
        this.intArgs = new int[1];
        this.floatArgs = new float[4];
        this.boolArgs = new boolean[4];
        this.stringArgs = new String[1];
        this.objectArgs = new Object[1];
        this.intArgs[0] = n4;
        this.floatArgs[0] = n;
        this.floatArgs[1] = n2;
        this.floatArgs[2] = n3;
        this.floatArgs[3] = n5;
        this.boolArgs[0] = b;
        this.boolArgs[1] = b2;
        this.boolArgs[2] = b3;
        this.boolArgs[3] = b4;
        this.stringArgs[0] = s;
        this.objectArgs[0] = o;
    }
    
    public CommandObject(final int command, final Object o, final boolean b, final String s, final float n, final float n2, final float n3, final int n4, final float n5) {
        this.Command = command;
        this.intArgs = new int[1];
        this.floatArgs = new float[4];
        this.boolArgs = new boolean[1];
        this.stringArgs = new String[1];
        this.objectArgs = new Object[1];
        this.intArgs[0] = n4;
        this.floatArgs[0] = n;
        this.floatArgs[1] = n2;
        this.floatArgs[2] = n3;
        this.floatArgs[3] = n5;
        this.boolArgs[0] = b;
        this.stringArgs[0] = s;
        this.objectArgs[0] = o;
    }
    
    static {
        INITIALIZE = 1;
        MOVE_LISTENER = 31;
        FADE_OUT_IN = 8;
        SET_LOOPING = 17;
        QUEUE_SOUND = 5;
        NEW_SOURCE = 10;
        REWIND = 25;
        SET_LISTENER_POSITION = 32;
        SET_LISTENER_ORIENTATION = 35;
        SET_VOLUME = 14;
        SET_MASTER_VOLUME = 36;
        RAW_DATA_STREAM = 11;
        FLUSH = 26;
        SET_TEMPORARY = 29;
        DEQUEUE_SOUND = 6;
        STOP = 24;
        PAUSE = 23;
        TURN_LISTENER = 33;
        CHECK_FADE_VOLUMES = 9;
        SET_DIST_OR_ROLL = 19;
        SET_POSITION = 13;
        UNLOAD_SOUND = 4;
        ACTIVATE = 28;
        PLAY = 21;
        SET_PITCH = 15;
        QUICK_PLAY = 12;
        LOAD_SOUND = 2;
        REMOVE_SOURCE = 30;
        NEW_LIBRARY = 37;
        SET_ATTENUATION = 18;
        SET_PRIORITY = 16;
        FADE_OUT = 7;
        CULL = 27;
        FEED_RAW_AUDIO_DATA = 22;
        SET_LISTENER_ANGLE = 34;
    }
}
