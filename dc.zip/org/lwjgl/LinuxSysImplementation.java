// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl;

import java.awt.Toolkit;

final class LinuxSysImplementation extends J2SESysImplementation
{
    private static final int JNI_VERSION = 19;
    
    public int getRequiredJNIVersion() {
        return 19;
    }
    
    public boolean openURL(final String url) {
        final String[] arr$;
        final String[] browsers = arr$ = new String[] { "xdg-open", "firefox", "mozilla", "opera", "konqueror", "nautilus", "galeon", "netscape" };
        final int len$ = arr$.length;
        int i$ = 0;
        while (i$ < len$) {
            final String browser = arr$[i$];
            try {
                LWJGLUtil.execPrivileged(new String[] { browser, url });
                return true;
            }
            catch (final Exception e) {
                e.printStackTrace(System.err);
                ++i$;
                continue;
            }
            break;
        }
        return false;
    }
    
    @Override
    public boolean has64Bit() {
        return true;
    }
    
    static {
        Toolkit.getDefaultToolkit();
    }
}
