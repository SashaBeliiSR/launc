// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl;

import java.nio.ByteOrder;
import java.nio.DoubleBuffer;
import java.nio.FloatBuffer;
import java.nio.LongBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.nio.Buffer;
import java.nio.ByteBuffer;

public final class NondirectBufferWrapper
{
    private static final int INITIAL_BUFFER_SIZE = 1;
    private static final ThreadLocal<CachedBuffers> thread_buffer;
    
    private static CachedBuffers getCachedBuffers(final int minimum_byte_size) {
        CachedBuffers buffers = NondirectBufferWrapper.thread_buffer.get();
        final int current_byte_size = buffers.byte_buffer.capacity();
        if (minimum_byte_size > current_byte_size) {
            buffers = new CachedBuffers(minimum_byte_size);
            NondirectBufferWrapper.thread_buffer.set(buffers);
        }
        return buffers;
    }
    
    public static ByteBuffer wrapNoCopyBuffer(final ByteBuffer buf, final int size) {
        BufferChecks.checkBufferSize(buf, size);
        return wrapNoCopyDirect(buf);
    }
    
    public static ShortBuffer wrapNoCopyBuffer(final ShortBuffer buf, final int size) {
        BufferChecks.checkBufferSize(buf, size);
        return wrapNoCopyDirect(buf);
    }
    
    public static IntBuffer wrapNoCopyBuffer(final IntBuffer buf, final int size) {
        BufferChecks.checkBufferSize(buf, size);
        return wrapNoCopyDirect(buf);
    }
    
    public static LongBuffer wrapNoCopyBuffer(final LongBuffer buf, final int size) {
        BufferChecks.checkBufferSize(buf, size);
        return wrapNoCopyDirect(buf);
    }
    
    public static FloatBuffer wrapNoCopyBuffer(final FloatBuffer buf, final int size) {
        BufferChecks.checkBufferSize(buf, size);
        return wrapNoCopyDirect(buf);
    }
    
    public static DoubleBuffer wrapNoCopyBuffer(final DoubleBuffer buf, final int size) {
        BufferChecks.checkBufferSize(buf, size);
        return wrapNoCopyDirect(buf);
    }
    
    public static ByteBuffer wrapBuffer(final ByteBuffer buf, final int size) {
        BufferChecks.checkBufferSize(buf, size);
        return wrapDirect(buf);
    }
    
    public static ShortBuffer wrapBuffer(final ShortBuffer buf, final int size) {
        BufferChecks.checkBufferSize(buf, size);
        return wrapDirect(buf);
    }
    
    public static IntBuffer wrapBuffer(final IntBuffer buf, final int size) {
        BufferChecks.checkBufferSize(buf, size);
        return wrapDirect(buf);
    }
    
    public static LongBuffer wrapBuffer(final LongBuffer buf, final int size) {
        BufferChecks.checkBufferSize(buf, size);
        return wrapDirect(buf);
    }
    
    public static FloatBuffer wrapBuffer(final FloatBuffer buf, final int size) {
        BufferChecks.checkBufferSize(buf, size);
        return wrapDirect(buf);
    }
    
    public static DoubleBuffer wrapBuffer(final DoubleBuffer buf, final int size) {
        BufferChecks.checkBufferSize(buf, size);
        return wrapDirect(buf);
    }
    
    public static ByteBuffer wrapDirect(final ByteBuffer buffer) {
        if (!buffer.isDirect()) {
            return doWrap(buffer);
        }
        return buffer;
    }
    
    public static ShortBuffer wrapDirect(final ShortBuffer buffer) {
        if (!buffer.isDirect()) {
            return doWrap(buffer);
        }
        return buffer;
    }
    
    public static FloatBuffer wrapDirect(final FloatBuffer buffer) {
        if (!buffer.isDirect()) {
            return doWrap(buffer);
        }
        return buffer;
    }
    
    public static IntBuffer wrapDirect(final IntBuffer buffer) {
        if (!buffer.isDirect()) {
            return doWrap(buffer);
        }
        return buffer;
    }
    
    public static LongBuffer wrapDirect(final LongBuffer buffer) {
        if (!buffer.isDirect()) {
            return doWrap(buffer);
        }
        return buffer;
    }
    
    public static DoubleBuffer wrapDirect(final DoubleBuffer buffer) {
        if (!buffer.isDirect()) {
            return doWrap(buffer);
        }
        return buffer;
    }
    
    public static ByteBuffer wrapNoCopyDirect(final ByteBuffer buffer) {
        if (!buffer.isDirect()) {
            return doNoCopyWrap(buffer);
        }
        return buffer;
    }
    
    public static ShortBuffer wrapNoCopyDirect(final ShortBuffer buffer) {
        if (!buffer.isDirect()) {
            return doNoCopyWrap(buffer);
        }
        return buffer;
    }
    
    public static FloatBuffer wrapNoCopyDirect(final FloatBuffer buffer) {
        if (!buffer.isDirect()) {
            return doNoCopyWrap(buffer);
        }
        return buffer;
    }
    
    public static IntBuffer wrapNoCopyDirect(final IntBuffer buffer) {
        if (!buffer.isDirect()) {
            return doNoCopyWrap(buffer);
        }
        return buffer;
    }
    
    public static LongBuffer wrapNoCopyDirect(final LongBuffer buffer) {
        if (!buffer.isDirect()) {
            return doNoCopyWrap(buffer);
        }
        return buffer;
    }
    
    public static DoubleBuffer wrapNoCopyDirect(final DoubleBuffer buffer) {
        if (!buffer.isDirect()) {
            return doNoCopyWrap(buffer);
        }
        return buffer;
    }
    
    public static void copy(final ByteBuffer src, final ByteBuffer dst) {
        if (dst != null && !dst.isDirect()) {
            final int saved_position = dst.position();
            dst.put(src);
            dst.position(saved_position);
        }
    }
    
    public static void copy(final ShortBuffer src, final ShortBuffer dst) {
        if (dst != null && !dst.isDirect()) {
            final int saved_position = dst.position();
            dst.put(src);
            dst.position(saved_position);
        }
    }
    
    public static void copy(final IntBuffer src, final IntBuffer dst) {
        if (dst != null && !dst.isDirect()) {
            final int saved_position = dst.position();
            dst.put(src);
            dst.position(saved_position);
        }
    }
    
    public static void copy(final FloatBuffer src, final FloatBuffer dst) {
        if (dst != null && !dst.isDirect()) {
            final int saved_position = dst.position();
            dst.put(src);
            dst.position(saved_position);
        }
    }
    
    public static void copy(final LongBuffer src, final LongBuffer dst) {
        if (dst != null && !dst.isDirect()) {
            final int saved_position = dst.position();
            dst.put(src);
            dst.position(saved_position);
        }
    }
    
    public static void copy(final DoubleBuffer src, final DoubleBuffer dst) {
        if (dst != null && !dst.isDirect()) {
            final int saved_position = dst.position();
            dst.put(src);
            dst.position(saved_position);
        }
    }
    
    private static ByteBuffer doNoCopyWrap(final ByteBuffer buffer) {
        final ByteBuffer direct_buffer = lookupBuffer(buffer);
        direct_buffer.limit(buffer.limit());
        direct_buffer.position(buffer.position());
        return direct_buffer;
    }
    
    private static ShortBuffer doNoCopyWrap(final ShortBuffer buffer) {
        final ShortBuffer direct_buffer = lookupBuffer(buffer);
        direct_buffer.limit(buffer.limit());
        direct_buffer.position(buffer.position());
        return direct_buffer;
    }
    
    private static IntBuffer doNoCopyWrap(final IntBuffer buffer) {
        final IntBuffer direct_buffer = lookupBuffer(buffer);
        direct_buffer.limit(buffer.limit());
        direct_buffer.position(buffer.position());
        return direct_buffer;
    }
    
    private static FloatBuffer doNoCopyWrap(final FloatBuffer buffer) {
        final FloatBuffer direct_buffer = lookupBuffer(buffer);
        direct_buffer.limit(buffer.limit());
        direct_buffer.position(buffer.position());
        return direct_buffer;
    }
    
    private static LongBuffer doNoCopyWrap(final LongBuffer buffer) {
        final LongBuffer direct_buffer = lookupBuffer(buffer);
        direct_buffer.limit(buffer.limit());
        direct_buffer.position(buffer.position());
        return direct_buffer;
    }
    
    private static DoubleBuffer doNoCopyWrap(final DoubleBuffer buffer) {
        final DoubleBuffer direct_buffer = lookupBuffer(buffer);
        direct_buffer.limit(buffer.limit());
        direct_buffer.position(buffer.position());
        return direct_buffer;
    }
    
    private static ByteBuffer lookupBuffer(final ByteBuffer buffer) {
        return getCachedBuffers(buffer.remaining()).byte_buffer;
    }
    
    private static ByteBuffer doWrap(final ByteBuffer buffer) {
        final ByteBuffer direct_buffer = lookupBuffer(buffer);
        direct_buffer.clear();
        final int saved_position = buffer.position();
        direct_buffer.put(buffer);
        buffer.position(saved_position);
        direct_buffer.flip();
        return direct_buffer;
    }
    
    private static ShortBuffer lookupBuffer(final ShortBuffer buffer) {
        final CachedBuffers buffers = getCachedBuffers(buffer.remaining() * 2);
        return (buffer.order() == ByteOrder.LITTLE_ENDIAN) ? buffers.short_buffer_little : buffers.short_buffer_big;
    }
    
    private static ShortBuffer doWrap(final ShortBuffer buffer) {
        final ShortBuffer direct_buffer = lookupBuffer(buffer);
        direct_buffer.clear();
        final int saved_position = buffer.position();
        direct_buffer.put(buffer);
        buffer.position(saved_position);
        direct_buffer.flip();
        return direct_buffer;
    }
    
    private static FloatBuffer lookupBuffer(final FloatBuffer buffer) {
        final CachedBuffers buffers = getCachedBuffers(buffer.remaining() * 4);
        return (buffer.order() == ByteOrder.LITTLE_ENDIAN) ? buffers.float_buffer_little : buffers.float_buffer_big;
    }
    
    private static FloatBuffer doWrap(final FloatBuffer buffer) {
        final FloatBuffer direct_buffer = lookupBuffer(buffer);
        direct_buffer.clear();
        final int saved_position = buffer.position();
        direct_buffer.put(buffer);
        buffer.position(saved_position);
        direct_buffer.flip();
        return direct_buffer;
    }
    
    private static IntBuffer lookupBuffer(final IntBuffer buffer) {
        final CachedBuffers buffers = getCachedBuffers(buffer.remaining() * 4);
        return (buffer.order() == ByteOrder.LITTLE_ENDIAN) ? buffers.int_buffer_little : buffers.int_buffer_big;
    }
    
    private static IntBuffer doWrap(final IntBuffer buffer) {
        final IntBuffer direct_buffer = lookupBuffer(buffer);
        direct_buffer.clear();
        final int saved_position = buffer.position();
        direct_buffer.put(buffer);
        buffer.position(saved_position);
        direct_buffer.flip();
        return direct_buffer;
    }
    
    private static LongBuffer lookupBuffer(final LongBuffer buffer) {
        final CachedBuffers buffers = getCachedBuffers(buffer.remaining() * 8);
        return (buffer.order() == ByteOrder.LITTLE_ENDIAN) ? buffers.long_buffer_little : buffers.long_buffer_big;
    }
    
    private static LongBuffer doWrap(final LongBuffer buffer) {
        final LongBuffer direct_buffer = lookupBuffer(buffer);
        direct_buffer.clear();
        final int saved_position = buffer.position();
        direct_buffer.put(buffer);
        buffer.position(saved_position);
        direct_buffer.flip();
        return direct_buffer;
    }
    
    private static DoubleBuffer lookupBuffer(final DoubleBuffer buffer) {
        final CachedBuffers buffers = getCachedBuffers(buffer.remaining() * 8);
        return (buffer.order() == ByteOrder.LITTLE_ENDIAN) ? buffers.double_buffer_little : buffers.double_buffer_big;
    }
    
    private static DoubleBuffer doWrap(final DoubleBuffer buffer) {
        final DoubleBuffer direct_buffer = lookupBuffer(buffer);
        direct_buffer.clear();
        final int saved_position = buffer.position();
        direct_buffer.put(buffer);
        buffer.position(saved_position);
        direct_buffer.flip();
        return direct_buffer;
    }
    
    static {
        thread_buffer = new ThreadLocal<CachedBuffers>() {
            @Override
            protected CachedBuffers initialValue() {
                return new CachedBuffers(1);
            }
        };
    }
    
    private static final class CachedBuffers
    {
        private final ByteBuffer byte_buffer;
        private final ShortBuffer short_buffer_big;
        private final IntBuffer int_buffer_big;
        private final FloatBuffer float_buffer_big;
        private final LongBuffer long_buffer_big;
        private final DoubleBuffer double_buffer_big;
        private final ShortBuffer short_buffer_little;
        private final IntBuffer int_buffer_little;
        private final FloatBuffer float_buffer_little;
        private final LongBuffer long_buffer_little;
        private final DoubleBuffer double_buffer_little;
        
        private CachedBuffers(final int size) {
            this.byte_buffer = ByteBuffer.allocateDirect(size);
            this.short_buffer_big = this.byte_buffer.asShortBuffer();
            this.int_buffer_big = this.byte_buffer.asIntBuffer();
            this.float_buffer_big = this.byte_buffer.asFloatBuffer();
            this.long_buffer_big = this.byte_buffer.asLongBuffer();
            this.double_buffer_big = this.byte_buffer.asDoubleBuffer();
            this.byte_buffer.order(ByteOrder.LITTLE_ENDIAN);
            this.short_buffer_little = this.byte_buffer.asShortBuffer();
            this.int_buffer_little = this.byte_buffer.asIntBuffer();
            this.float_buffer_little = this.byte_buffer.asFloatBuffer();
            this.long_buffer_little = this.byte_buffer.asLongBuffer();
            this.double_buffer_little = this.byte_buffer.asDoubleBuffer();
        }
    }
}
