// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import org.lwjgl.PointerBuffer;
import org.lwjgl.LWJGLUtil;
import org.lwjgl.LWJGLException;

abstract class AbstractDrawable implements DrawableLWJGL
{
    protected PeerInfo peer_info;
    protected Context context;
    
    protected AbstractDrawable() {
    }
    
    public Context getContext() {
        synchronized (GlobalLock.lock) {
            return this.context;
        }
    }
    
    public Context createSharedContext() throws LWJGLException {
        synchronized (GlobalLock.lock) {
            this.checkDestroyed();
            return new Context(this.peer_info, this.context.getContextAttribs(), this.context);
        }
    }
    
    public boolean isCurrent() throws LWJGLException {
        synchronized (GlobalLock.lock) {
            this.checkDestroyed();
            return this.context.isCurrent();
        }
    }
    
    public void makeCurrent() throws LWJGLException {
        synchronized (GlobalLock.lock) {
            this.checkDestroyed();
            this.context.makeCurrent();
        }
    }
    
    public void releaseContext() throws LWJGLException {
        synchronized (GlobalLock.lock) {
            this.checkDestroyed();
            if (this.context.isCurrent()) {
                Context.releaseCurrentContext();
            }
        }
    }
    
    public void destroy() {
        synchronized (GlobalLock.lock) {
            if (this.context == null) {
                return;
            }
            try {
                this.releaseContext();
                this.context.forceDestroy();
                this.context = null;
                if (this.peer_info != null) {
                    this.peer_info.destroy();
                    this.peer_info = null;
                }
            }
            catch (final LWJGLException e) {
                LWJGLUtil.log("Exception occurred while destroying Drawable: " + e);
            }
        }
    }
    
    public void setCLSharingProperties(final PointerBuffer properties) throws LWJGLException {
        synchronized (GlobalLock.lock) {
            this.checkDestroyed();
            this.context.setCLSharingProperties(properties);
        }
    }
    
    protected final void checkDestroyed() {
        if (this.context == null) {
            throw new IllegalStateException("The Drawable has no context available.");
        }
    }
}
