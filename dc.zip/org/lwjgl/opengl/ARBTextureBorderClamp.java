// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class ARBTextureBorderClamp
{
    public static final int GL_CLAMP_TO_BORDER_ARB = 33069;
    
    private ARBTextureBorderClamp() {
    }
}
