// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import org.lwjgl.LWJGLException;

interface DrawableLWJGL extends Drawable
{
    Context getContext();
    
    Context createSharedContext() throws LWJGLException;
}
