// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import java.nio.IntBuffer;

public final class ARBDrawIndirect
{
    public static final int GL_DRAW_INDIRECT_BUFFER = 36671;
    public static final int GL_DRAW_INDIRECT_BUFFER_BINDING = 36675;
    
    private ARBDrawIndirect() {
    }
    
    public static void glDrawArraysIndirect(final int mode, final IntBuffer indirect) {
        GL40.glDrawArraysIndirect(mode, indirect);
    }
    
    public static void glDrawElementsIndirect(final int mode, final int type, final IntBuffer indirect) {
        GL40.glDrawElementsIndirect(mode, type, indirect);
    }
}
