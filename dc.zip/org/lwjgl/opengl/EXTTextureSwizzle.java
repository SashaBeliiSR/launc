// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class EXTTextureSwizzle
{
    public static final int GL_TEXTURE_SWIZZLE_R_EXT = 36418;
    public static final int GL_TEXTURE_SWIZZLE_G_EXT = 36419;
    public static final int GL_TEXTURE_SWIZZLE_B_EXT = 36420;
    public static final int GL_TEXTURE_SWIZZLE_A_EXT = 36421;
    public static final int GL_TEXTURE_SWIZZLE_RGBA_EXT = 36422;
    
    private EXTTextureSwizzle() {
    }
}
