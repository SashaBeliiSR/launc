// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class EXTPackedDepthStencil
{
    public static final int GL_DEPTH_STENCIL_EXT = 34041;
    public static final int GL_UNSIGNED_INT_24_8_EXT = 34042;
    public static final int GL_DEPTH24_STENCIL8_EXT = 35056;
    public static final int GL_TEXTURE_STENCIL_SIZE_EXT = 35057;
    
    private EXTPackedDepthStencil() {
    }
}
