// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class ARBSeamlessCubeMap
{
    public static final int GL_TEXTURE_CUBE_MAP_SEAMLESS = 34895;
    
    private ARBSeamlessCubeMap() {
    }
}
