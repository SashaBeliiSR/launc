// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import org.lwjgl.BufferChecks;
import java.nio.IntBuffer;

public final class EXTMultiDrawArrays
{
    private EXTMultiDrawArrays() {
    }
    
    public static void glMultiDrawArraysEXT(final int mode, final IntBuffer piFirst, final IntBuffer piCount) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glMultiDrawArraysEXT;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(piFirst);
        BufferChecks.checkBuffer(piCount, piFirst.remaining());
        nglMultiDrawArraysEXT(mode, piFirst, piFirst.position(), piCount, piCount.position(), piFirst.remaining(), function_pointer);
    }
    
    static native void nglMultiDrawArraysEXT(final int p0, final IntBuffer p1, final int p2, final IntBuffer p3, final int p4, final int p5, final long p6);
}
