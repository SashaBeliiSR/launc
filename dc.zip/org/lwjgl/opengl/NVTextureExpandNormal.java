// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class NVTextureExpandNormal
{
    public static final int GL_TEXTURE_UNSIGNED_REMAP_MODE_NV = 34959;
    
    private NVTextureExpandNormal() {
    }
}
