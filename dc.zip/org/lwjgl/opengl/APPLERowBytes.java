// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class APPLERowBytes
{
    public static final int GL_PACK_ROW_BYTES_APPLE = 35349;
    public static final int GL_UNPACK_ROW_BYTES_APPLE = 35350;
    
    private APPLERowBytes() {
    }
}
