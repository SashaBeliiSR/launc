// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class APPLEYcbcr422
{
    public static final int GL_YCBCR_422_APPLE = 34233;
    public static final int GL_UNSIGNED_SHORT_8_8_APPLE = 34234;
    public static final int GL_UNSIGNED_SHORT_8_8_REV_APPLE = 34235;
    
    private APPLEYcbcr422() {
    }
}
