// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import java.nio.ByteBuffer;
import org.lwjgl.BufferChecks;
import java.nio.IntBuffer;

public final class AMDPerformanceMonitor
{
    public static final int GL_COUNTER_TYPE_AMD = 35776;
    public static final int GL_COUNTER_RANGE_AMD = 35777;
    public static final int GL_UNSIGNED_INT = 5125;
    public static final int GL_FLOAT = 5126;
    public static final int GL_UNSIGNED_INT64_AMD = 35778;
    public static final int GL_PERCENTAGE_AMD = 35779;
    public static final int GL_PERFMON_RESULT_AVAILABLE_AMD = 35780;
    public static final int GL_PERFMON_RESULT_SIZE_AMD = 35781;
    public static final int GL_PERFMON_RESULT_AMD = 35782;
    
    private AMDPerformanceMonitor() {
    }
    
    public static void glGetPerfMonitorGroupsAMD(final IntBuffer numGroups, final IntBuffer groups) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGetPerfMonitorGroupsAMD;
        BufferChecks.checkFunctionAddress(function_pointer);
        if (numGroups != null) {
            BufferChecks.checkBuffer(numGroups, 1);
        }
        BufferChecks.checkDirect(groups);
        nglGetPerfMonitorGroupsAMD(numGroups, (numGroups != null) ? numGroups.position() : 0, groups.remaining(), groups, groups.position(), function_pointer);
    }
    
    static native void nglGetPerfMonitorGroupsAMD(final IntBuffer p0, final int p1, final int p2, final IntBuffer p3, final int p4, final long p5);
    
    public static void glGetPerfMonitorCountersAMD(final int group, final IntBuffer numCounters, final IntBuffer maxActiveCounters, final IntBuffer counters) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGetPerfMonitorCountersAMD;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkBuffer(numCounters, 1);
        BufferChecks.checkBuffer(maxActiveCounters, 1);
        BufferChecks.checkDirect(counters);
        nglGetPerfMonitorCountersAMD(group, numCounters, numCounters.position(), maxActiveCounters, maxActiveCounters.position(), counters.remaining(), counters, counters.position(), function_pointer);
    }
    
    static native void nglGetPerfMonitorCountersAMD(final int p0, final IntBuffer p1, final int p2, final IntBuffer p3, final int p4, final int p5, final IntBuffer p6, final int p7, final long p8);
    
    public static void glGetPerfMonitorGroupStringAMD(final int group, final IntBuffer length, final ByteBuffer groupString) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGetPerfMonitorGroupStringAMD;
        BufferChecks.checkFunctionAddress(function_pointer);
        if (length != null) {
            BufferChecks.checkBuffer(length, 1);
        }
        BufferChecks.checkDirect(groupString);
        nglGetPerfMonitorGroupStringAMD(group, groupString.remaining(), length, (length != null) ? length.position() : 0, groupString, groupString.position(), function_pointer);
    }
    
    static native void nglGetPerfMonitorGroupStringAMD(final int p0, final int p1, final IntBuffer p2, final int p3, final ByteBuffer p4, final int p5, final long p6);
    
    public static String glGetPerfMonitorGroupStringAMD(final int group, final int bufSize) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGetPerfMonitorGroupStringAMD;
        BufferChecks.checkFunctionAddress(function_pointer);
        final IntBuffer groupString_length = APIUtil.getLengths();
        final ByteBuffer groupString = APIUtil.getBufferByte(bufSize);
        nglGetPerfMonitorGroupStringAMD(group, bufSize, groupString_length, 0, groupString, groupString.position(), function_pointer);
        groupString.limit(groupString_length.get(0));
        return APIUtil.getString(groupString);
    }
    
    public static void glGetPerfMonitorCounterStringAMD(final int group, final int counter, final IntBuffer length, final ByteBuffer counterString) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGetPerfMonitorCounterStringAMD;
        BufferChecks.checkFunctionAddress(function_pointer);
        if (length != null) {
            BufferChecks.checkBuffer(length, 1);
        }
        BufferChecks.checkDirect(counterString);
        nglGetPerfMonitorCounterStringAMD(group, counter, counterString.remaining(), length, (length != null) ? length.position() : 0, counterString, counterString.position(), function_pointer);
    }
    
    static native void nglGetPerfMonitorCounterStringAMD(final int p0, final int p1, final int p2, final IntBuffer p3, final int p4, final ByteBuffer p5, final int p6, final long p7);
    
    public static String glGetPerfMonitorCounterStringAMD(final int group, final int counter, final int bufSize) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGetPerfMonitorCounterStringAMD;
        BufferChecks.checkFunctionAddress(function_pointer);
        final IntBuffer counterString_length = APIUtil.getLengths();
        final ByteBuffer counterString = APIUtil.getBufferByte(bufSize);
        nglGetPerfMonitorCounterStringAMD(group, counter, bufSize, counterString_length, 0, counterString, counterString.position(), function_pointer);
        counterString.limit(counterString_length.get(0));
        return APIUtil.getString(counterString);
    }
    
    public static void glGetPerfMonitorCounterInfoAMD(final int group, final int counter, final int pname, final ByteBuffer data) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGetPerfMonitorCounterInfoAMD;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkBuffer(data, 16);
        nglGetPerfMonitorCounterInfoAMD(group, counter, pname, data, data.position(), function_pointer);
    }
    
    static native void nglGetPerfMonitorCounterInfoAMD(final int p0, final int p1, final int p2, final ByteBuffer p3, final int p4, final long p5);
    
    public static void glGenPerfMonitorsAMD(final IntBuffer monitors) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGenPerfMonitorsAMD;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(monitors);
        nglGenPerfMonitorsAMD(monitors.remaining(), monitors, monitors.position(), function_pointer);
    }
    
    static native void nglGenPerfMonitorsAMD(final int p0, final IntBuffer p1, final int p2, final long p3);
    
    public static int glGenPerfMonitorsAMD() {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGenPerfMonitorsAMD;
        BufferChecks.checkFunctionAddress(function_pointer);
        final IntBuffer monitors = APIUtil.getBufferInt();
        nglGenPerfMonitorsAMD(1, monitors, monitors.position(), function_pointer);
        return monitors.get(0);
    }
    
    public static void glDeletePerfMonitorsAMD(final IntBuffer monitors) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glDeletePerfMonitorsAMD;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(monitors);
        nglDeletePerfMonitorsAMD(monitors.remaining(), monitors, monitors.position(), function_pointer);
    }
    
    static native void nglDeletePerfMonitorsAMD(final int p0, final IntBuffer p1, final int p2, final long p3);
    
    public static void glDeletePerfMonitorsAMD(final int monitor) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glDeletePerfMonitorsAMD;
        BufferChecks.checkFunctionAddress(function_pointer);
        nglDeletePerfMonitorsAMD(1, APIUtil.getBufferInt().put(0, monitor), 0, function_pointer);
    }
    
    public static void glSelectPerfMonitorCountersAMD(final int monitor, final boolean enable, final int group, final IntBuffer counterList) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glSelectPerfMonitorCountersAMD;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(counterList);
        nglSelectPerfMonitorCountersAMD(monitor, enable, group, counterList.remaining(), counterList, counterList.position(), function_pointer);
    }
    
    static native void nglSelectPerfMonitorCountersAMD(final int p0, final boolean p1, final int p2, final int p3, final IntBuffer p4, final int p5, final long p6);
    
    public static void glSelectPerfMonitorCountersAMD(final int monitor, final boolean enable, final int group, final int counter) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glSelectPerfMonitorCountersAMD;
        BufferChecks.checkFunctionAddress(function_pointer);
        nglSelectPerfMonitorCountersAMD(monitor, enable, group, 1, APIUtil.getBufferInt().put(0, counter), 0, function_pointer);
    }
    
    public static void glBeginPerfMonitorAMD(final int monitor) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glBeginPerfMonitorAMD;
        BufferChecks.checkFunctionAddress(function_pointer);
        nglBeginPerfMonitorAMD(monitor, function_pointer);
    }
    
    static native void nglBeginPerfMonitorAMD(final int p0, final long p1);
    
    public static void glEndPerfMonitorAMD(final int monitor) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glEndPerfMonitorAMD;
        BufferChecks.checkFunctionAddress(function_pointer);
        nglEndPerfMonitorAMD(monitor, function_pointer);
    }
    
    static native void nglEndPerfMonitorAMD(final int p0, final long p1);
    
    public static void glGetPerfMonitorCounterDataAMD(final int monitor, final int pname, final IntBuffer data, final IntBuffer bytesWritten) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGetPerfMonitorCounterDataAMD;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(data);
        if (bytesWritten != null) {
            BufferChecks.checkBuffer(bytesWritten, 1);
        }
        nglGetPerfMonitorCounterDataAMD(monitor, pname, data.remaining(), data, data.position(), bytesWritten, (bytesWritten != null) ? bytesWritten.position() : 0, function_pointer);
    }
    
    static native void nglGetPerfMonitorCounterDataAMD(final int p0, final int p1, final int p2, final IntBuffer p3, final int p4, final IntBuffer p5, final int p6, final long p7);
    
    public static int glGetPerfMonitorCounterDataAMD(final int monitor, final int pname) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGetPerfMonitorCounterDataAMD;
        BufferChecks.checkFunctionAddress(function_pointer);
        final IntBuffer data = APIUtil.getBufferInt();
        nglGetPerfMonitorCounterDataAMD(monitor, pname, 4, data, data.position(), null, 0, function_pointer);
        return data.get(0);
    }
}
