// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class EXTTextureMirrorClamp
{
    public static final int GL_MIRROR_CLAMP_EXT = 34626;
    public static final int GL_MIRROR_CLAMP_TO_EDGE_EXT = 34627;
    public static final int GL_MIRROR_CLAMP_TO_BORDER_EXT = 35090;
    
    private EXTTextureMirrorClamp() {
    }
}
