// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class EXTAbgr
{
    public static final int GL_ABGR_EXT = 32768;
    
    private EXTAbgr() {
    }
}
