// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class EXTTextureCompressionS3TC
{
    public static final int GL_COMPRESSED_RGB_S3TC_DXT1_EXT = 33776;
    public static final int GL_COMPRESSED_RGBA_S3TC_DXT1_EXT = 33777;
    public static final int GL_COMPRESSED_RGBA_S3TC_DXT3_EXT = 33778;
    public static final int GL_COMPRESSED_RGBA_S3TC_DXT5_EXT = 33779;
    
    private EXTTextureCompressionS3TC() {
    }
}
