// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class NVTexgenReflection
{
    public static final int GL_NORMAL_MAP_NV = 34065;
    public static final int GL_REFLECTION_MAP_NV = 34066;
    
    private NVTexgenReflection() {
    }
}
