// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class NVTextureEnvCombine4
{
    public static final int GL_COMBINE4_NV = 34051;
    public static final int GL_SOURCE3_RGB_NV = 34179;
    public static final int GL_SOURCE3_ALPHA_NV = 34187;
    public static final int GL_OPERAND3_RGB_NV = 34195;
    public static final int GL_OPERAND3_ALPHA_NV = 34203;
    
    private NVTextureEnvCombine4() {
    }
}
