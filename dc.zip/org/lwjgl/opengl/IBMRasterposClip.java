// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class IBMRasterposClip
{
    public static final int GL_RASTER_POSITION_UNCLIPPED_IBM = 103010;
    
    private IBMRasterposClip() {
    }
}
