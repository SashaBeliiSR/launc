// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class NVTextureRectangle
{
    public static final int GL_TEXTURE_RECTANGLE_NV = 34037;
    public static final int GL_TEXTURE_BINDING_RECTANGLE_NV = 34038;
    public static final int GL_PROXY_TEXTURE_RECTANGLE_NV = 34039;
    public static final int GL_MAX_RECTANGLE_TEXTURE_SIZE_NV = 34040;
    
    private NVTextureRectangle() {
    }
}
