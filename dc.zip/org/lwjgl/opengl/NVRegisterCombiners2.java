// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import org.lwjgl.BufferChecks;
import java.nio.FloatBuffer;

public final class NVRegisterCombiners2
{
    public static final int GL_PER_STAGE_CONSTANTS_NV = 34101;
    
    private NVRegisterCombiners2() {
    }
    
    public static void glCombinerStageParameterNV(final int stage, final int pname, final FloatBuffer params) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glCombinerStageParameterfvNV;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkBuffer(params, 4);
        nglCombinerStageParameterfvNV(stage, pname, params, params.position(), function_pointer);
    }
    
    static native void nglCombinerStageParameterfvNV(final int p0, final int p1, final FloatBuffer p2, final int p3, final long p4);
    
    public static void glGetCombinerStageParameterNV(final int stage, final int pname, final FloatBuffer params) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGetCombinerStageParameterfvNV;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkBuffer(params, 4);
        nglGetCombinerStageParameterfvNV(stage, pname, params, params.position(), function_pointer);
    }
    
    static native void nglGetCombinerStageParameterfvNV(final int p0, final int p1, final FloatBuffer p2, final int p3, final long p4);
}
