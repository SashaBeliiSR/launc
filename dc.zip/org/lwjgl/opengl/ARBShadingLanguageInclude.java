// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import java.nio.IntBuffer;
import org.lwjgl.BufferChecks;
import java.nio.ByteBuffer;

public final class ARBShadingLanguageInclude
{
    public static final int GL_SHADER_INCLUDE_ARB = 36270;
    public static final int GL_NAMED_STRING_LENGTH_ARB = 36329;
    public static final int GL_NAMED_STRING_TYPE_ARB = 36330;
    
    private ARBShadingLanguageInclude() {
    }
    
    public static void glNamedStringARB(final int type, final ByteBuffer name, final ByteBuffer string) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glNamedStringARB;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(name);
        BufferChecks.checkDirect(string);
        nglNamedStringARB(type, name.remaining(), name, name.position(), string.remaining(), string, string.position(), function_pointer);
    }
    
    static native void nglNamedStringARB(final int p0, final int p1, final ByteBuffer p2, final int p3, final int p4, final ByteBuffer p5, final int p6, final long p7);
    
    public static void glNamedStringARB(final int type, final CharSequence name, final CharSequence string) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glNamedStringARB;
        BufferChecks.checkFunctionAddress(function_pointer);
        nglNamedStringARB(type, name.length(), APIUtil.getBuffer(name), 0, string.length(), APIUtil.getBuffer(string, name.length()), name.length(), function_pointer);
    }
    
    public static void glDeleteNamedStringARB(final ByteBuffer name) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glDeleteNamedStringARB;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(name);
        nglDeleteNamedStringARB(name.remaining(), name, name.position(), function_pointer);
    }
    
    static native void nglDeleteNamedStringARB(final int p0, final ByteBuffer p1, final int p2, final long p3);
    
    public static void glDeleteNamedStringARB(final CharSequence name) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glDeleteNamedStringARB;
        BufferChecks.checkFunctionAddress(function_pointer);
        nglDeleteNamedStringARB(name.length(), APIUtil.getBuffer(name), 0, function_pointer);
    }
    
    public static void glCompileShaderIncludeARB(final int shader, final int count, final ByteBuffer path) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glCompileShaderIncludeARB;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(path);
        BufferChecks.checkNullTerminated(path, count);
        nglCompileShaderIncludeARB(shader, count, path, path.position(), null, 0, function_pointer);
    }
    
    static native void nglCompileShaderIncludeARB(final int p0, final int p1, final ByteBuffer p2, final int p3, final IntBuffer p4, final int p5, final long p6);
    
    public static void glCompileShaderIncludeARB(final int shader, final CharSequence[] path) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glCompileShaderIncludeARB;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkArray(path);
        nglCompileShaderIncludeARB2(shader, path.length, APIUtil.getBuffer(path), 0, APIUtil.getLengths(path), 0, function_pointer);
    }
    
    static native void nglCompileShaderIncludeARB2(final int p0, final int p1, final ByteBuffer p2, final int p3, final IntBuffer p4, final int p5, final long p6);
    
    public static boolean glIsNamedStringARB(final ByteBuffer name) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glIsNamedStringARB;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(name);
        final boolean __result = nglIsNamedStringARB(name.remaining(), name, name.position(), function_pointer);
        return __result;
    }
    
    static native boolean nglIsNamedStringARB(final int p0, final ByteBuffer p1, final int p2, final long p3);
    
    public static boolean glIsNamedStringARB(final CharSequence name) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glIsNamedStringARB;
        BufferChecks.checkFunctionAddress(function_pointer);
        final boolean __result = nglIsNamedStringARB(name.length(), APIUtil.getBuffer(name), 0, function_pointer);
        return __result;
    }
    
    public static void glGetNamedStringARB(final ByteBuffer name, final IntBuffer stringlen, final ByteBuffer string) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGetNamedStringARB;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(name);
        if (stringlen != null) {
            BufferChecks.checkBuffer(stringlen, 1);
        }
        BufferChecks.checkDirect(string);
        nglGetNamedStringARB(name.remaining(), name, name.position(), string.remaining(), stringlen, (stringlen != null) ? stringlen.position() : 0, string, string.position(), function_pointer);
    }
    
    static native void nglGetNamedStringARB(final int p0, final ByteBuffer p1, final int p2, final int p3, final IntBuffer p4, final int p5, final ByteBuffer p6, final int p7, final long p8);
    
    public static void glGetNamedStringARB(final CharSequence name, final IntBuffer stringlen, final ByteBuffer string) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGetNamedStringARB;
        BufferChecks.checkFunctionAddress(function_pointer);
        if (stringlen != null) {
            BufferChecks.checkBuffer(stringlen, 1);
        }
        BufferChecks.checkDirect(string);
        nglGetNamedStringARB(name.length(), APIUtil.getBuffer(name), 0, string.remaining(), stringlen, (stringlen != null) ? stringlen.position() : 0, string, string.position(), function_pointer);
    }
    
    public static String glGetNamedStringARB(final CharSequence name, final int bufSize) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGetNamedStringARB;
        BufferChecks.checkFunctionAddress(function_pointer);
        final IntBuffer string_length = APIUtil.getLengths();
        final ByteBuffer string = APIUtil.getBufferByte(bufSize + name.length());
        nglGetNamedStringARB(name.length(), APIUtil.getBuffer(name), 0, bufSize, string_length, 0, string, string.position(), function_pointer);
        string.limit(name.length() + string_length.get(0));
        return APIUtil.getString(string);
    }
    
    public static void glGetNamedStringARB(final ByteBuffer name, final int pname, final IntBuffer params) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGetNamedStringivARB;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(name);
        BufferChecks.checkBuffer(params, 1);
        nglGetNamedStringivARB(name.remaining(), name, name.position(), pname, params, params.position(), function_pointer);
    }
    
    static native void nglGetNamedStringivARB(final int p0, final ByteBuffer p1, final int p2, final int p3, final IntBuffer p4, final int p5, final long p6);
    
    public static void glGetNamedStringiARB(final CharSequence name, final int pname, final IntBuffer params) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGetNamedStringivARB;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkBuffer(params, 1);
        nglGetNamedStringivARB(name.length(), APIUtil.getBuffer(name), 0, pname, params, params.position(), function_pointer);
    }
    
    public static int glGetNamedStringiARB(final CharSequence name, final int pname) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGetNamedStringivARB;
        BufferChecks.checkFunctionAddress(function_pointer);
        final IntBuffer params = APIUtil.getBufferInt();
        nglGetNamedStringivARB(name.length(), APIUtil.getBuffer(name), 0, pname, params, params.position(), function_pointer);
        return params.get(0);
    }
}
