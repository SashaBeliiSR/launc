// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class NVMultisampleFilterHint
{
    public static final int GL_MULTISAMPLE_FILTER_HINT_NV = 34100;
    
    private NVMultisampleFilterHint() {
    }
}
