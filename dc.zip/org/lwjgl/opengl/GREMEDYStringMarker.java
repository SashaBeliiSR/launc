// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import org.lwjgl.BufferChecks;
import java.nio.ByteBuffer;

public final class GREMEDYStringMarker
{
    private GREMEDYStringMarker() {
    }
    
    public static void glStringMarkerGREMEDY(final ByteBuffer string) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glStringMarkerGREMEDY;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(string);
        nglStringMarkerGREMEDY(string.remaining(), string, string.position(), function_pointer);
    }
    
    static native void nglStringMarkerGREMEDY(final int p0, final ByteBuffer p1, final int p2, final long p3);
    
    public static void glStringMarkerGREMEDY(final CharSequence string) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glStringMarkerGREMEDY;
        BufferChecks.checkFunctionAddress(function_pointer);
        nglStringMarkerGREMEDY(string.length(), APIUtil.getBuffer(string), 0, function_pointer);
    }
}
