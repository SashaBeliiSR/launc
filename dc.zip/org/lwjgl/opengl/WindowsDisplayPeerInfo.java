// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import java.nio.ByteBuffer;
import org.lwjgl.LWJGLException;

final class WindowsDisplayPeerInfo extends WindowsPeerInfo
{
    private final PixelFormat pixel_format;
    
    WindowsDisplayPeerInfo(final PixelFormat pixel_format) throws LWJGLException {
        this.pixel_format = pixel_format;
        GLContext.loadOpenGLLibrary();
    }
    
    PixelFormat getPixelFormat() {
        return this.pixel_format;
    }
    
    void initDC(final long hwnd, final long hdc) throws LWJGLException {
        nInitDC(this.getHandle(), hwnd, hdc);
    }
    
    private static native void nInitDC(final ByteBuffer p0, final long p1, final long p2);
    
    @Override
    protected void doLockAndInitHandle() throws LWJGLException {
    }
    
    @Override
    protected void doUnlock() throws LWJGLException {
    }
    
    @Override
    public void destroy() {
        super.destroy();
        GLContext.unloadOpenGLLibrary();
    }
}
