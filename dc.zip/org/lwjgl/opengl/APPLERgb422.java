// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class APPLERgb422
{
    public static final int GL_RGB_422_APPLE = 35359;
    public static final int GL_UNSIGNED_SHORT_8_8_APPLE = 34234;
    public static final int GL_UNSIGNED_SHORT_8_8_REV_APPLE = 34235;
    
    private APPLERgb422() {
    }
}
