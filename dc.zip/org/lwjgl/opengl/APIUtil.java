// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import org.lwjgl.LWJGLUtil;
import java.nio.DoubleBuffer;
import java.nio.FloatBuffer;
import java.nio.LongBuffer;
import java.nio.ShortBuffer;
import org.lwjgl.BufferUtils;
import java.nio.IntBuffer;
import java.nio.ByteBuffer;

final class APIUtil
{
    private static final int INITIAL_BUFFER_SIZE = 256;
    private static final int INITIAL_LENGTHS_SIZE = 4;
    private static final int BUFFERS_SIZE = 32;
    private static final ThreadLocal<char[]> arrayTL;
    private static final ThreadLocal<ByteBuffer> bufferTL;
    private static final ThreadLocal<IntBuffer> lengthsTL;
    private static final ThreadLocal<Buffers> buffersTL;
    
    private APIUtil() {
    }
    
    private static char[] getArray(final int size) {
        char[] array = APIUtil.arrayTL.get();
        if (array.length < size) {
            for (int sizeNew = array.length << 1; sizeNew < size; sizeNew <<= 1) {}
            array = new char[size];
            APIUtil.arrayTL.set(array);
        }
        return array;
    }
    
    static ByteBuffer getBufferByte(final int size) {
        ByteBuffer buffer = APIUtil.bufferTL.get();
        if (buffer.capacity() < size) {
            for (int sizeNew = buffer.capacity() << 1; sizeNew < size; sizeNew <<= 1) {}
            buffer = BufferUtils.createByteBuffer(size);
            APIUtil.bufferTL.set(buffer);
        }
        else {
            buffer.clear();
        }
        return buffer;
    }
    
    private static ByteBuffer getBufferByteOffset(final int size) {
        ByteBuffer buffer = APIUtil.bufferTL.get();
        if (buffer.capacity() < size) {
            for (int sizeNew = buffer.capacity() << 1; sizeNew < size; sizeNew <<= 1) {}
            final ByteBuffer bufferNew = BufferUtils.createByteBuffer(size);
            bufferNew.put(buffer);
            APIUtil.bufferTL.set(buffer = bufferNew);
        }
        else {
            buffer.position(buffer.limit());
            buffer.limit(buffer.capacity());
        }
        return buffer;
    }
    
    static ShortBuffer getBufferShort() {
        return APIUtil.buffersTL.get().shorts;
    }
    
    static IntBuffer getBufferInt() {
        return APIUtil.buffersTL.get().ints;
    }
    
    static LongBuffer getBufferLong() {
        return APIUtil.buffersTL.get().longs;
    }
    
    static FloatBuffer getBufferFloat() {
        return APIUtil.buffersTL.get().floats;
    }
    
    static DoubleBuffer getBufferDouble() {
        return APIUtil.buffersTL.get().doubles;
    }
    
    static IntBuffer getLengths() {
        return getLengths(1);
    }
    
    static IntBuffer getLengths(final int size) {
        IntBuffer lengths = APIUtil.lengthsTL.get();
        if (lengths.capacity() < size) {
            for (int sizeNew = lengths.capacity(); sizeNew < size; sizeNew <<= 1) {}
            lengths = BufferUtils.createIntBuffer(size);
            APIUtil.lengthsTL.set(lengths);
        }
        else {
            lengths.clear();
        }
        return lengths;
    }
    
    private static ByteBuffer encode(final ByteBuffer buffer, final CharSequence string) {
        for (int i = 0; i < string.length(); ++i) {
            final char c = string.charAt(i);
            if (LWJGLUtil.DEBUG && '\u0080' <= c) {
                buffer.put((byte)26);
            }
            else {
                buffer.put((byte)c);
            }
        }
        return buffer;
    }
    
    static String getString(final ByteBuffer buffer) {
        final int length = buffer.remaining();
        final char[] charArray = getArray(length);
        for (int i = buffer.position(); i < buffer.limit(); ++i) {
            charArray[i - buffer.position()] = (char)buffer.get(i);
        }
        return new String(charArray, 0, length);
    }
    
    static ByteBuffer getBuffer(final CharSequence string) {
        final ByteBuffer buffer = encode(getBufferByte(string.length()), string);
        buffer.flip();
        return buffer;
    }
    
    static ByteBuffer getBuffer(final CharSequence string, final int offset) {
        final ByteBuffer buffer = encode(getBufferByteOffset(offset + string.length()), string);
        buffer.flip();
        return buffer;
    }
    
    static ByteBuffer getBufferNT(final CharSequence string) {
        final ByteBuffer buffer = encode(getBufferByte(string.length() + 1), string);
        buffer.put((byte)0);
        buffer.flip();
        return buffer;
    }
    
    static int getTotalLength(final CharSequence[] strings) {
        int length = 0;
        for (final CharSequence string : strings) {
            length += string.length();
        }
        return length;
    }
    
    static ByteBuffer getBuffer(final CharSequence[] strings) {
        final ByteBuffer buffer = getBufferByte(getTotalLength(strings));
        for (final CharSequence string : strings) {
            encode(buffer, string);
        }
        buffer.flip();
        return buffer;
    }
    
    static ByteBuffer getBufferNT(final CharSequence[] strings) {
        final ByteBuffer buffer = getBufferByte(getTotalLength(strings) + strings.length);
        for (final CharSequence string : strings) {
            encode(buffer, string);
            buffer.put((byte)0);
        }
        buffer.flip();
        return buffer;
    }
    
    static IntBuffer getLengths(final CharSequence[] strings) {
        final IntBuffer buffer = getLengths(strings.length);
        for (final CharSequence string : strings) {
            buffer.put(string.length());
        }
        buffer.flip();
        return buffer;
    }
    
    static {
        arrayTL = new ThreadLocal<char[]>() {
            @Override
            protected char[] initialValue() {
                return new char[256];
            }
        };
        bufferTL = new ThreadLocal<ByteBuffer>() {
            @Override
            protected ByteBuffer initialValue() {
                return BufferUtils.createByteBuffer(256);
            }
        };
        lengthsTL = new ThreadLocal<IntBuffer>() {
            @Override
            protected IntBuffer initialValue() {
                return BufferUtils.createIntBuffer(4);
            }
        };
        buffersTL = new ThreadLocal<Buffers>() {
            @Override
            protected Buffers initialValue() {
                return new Buffers();
            }
        };
    }
    
    private static class Buffers
    {
        final ShortBuffer shorts;
        final IntBuffer ints;
        final LongBuffer longs;
        final FloatBuffer floats;
        final DoubleBuffer doubles;
        
        Buffers() {
            this.shorts = BufferUtils.createShortBuffer(32);
            this.ints = BufferUtils.createIntBuffer(32);
            this.longs = BufferUtils.createLongBuffer(32);
            this.floats = BufferUtils.createFloatBuffer(32);
            this.doubles = BufferUtils.createDoubleBuffer(32);
        }
    }
}
