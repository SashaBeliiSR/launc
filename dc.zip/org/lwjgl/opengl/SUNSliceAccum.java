// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class SUNSliceAccum
{
    public static final int GL_SLICE_ACCUM_SUN = 34252;
    
    private SUNSliceAccum() {
    }
}
