// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import java.util.regex.Matcher;
import java.io.IOException;
import java.util.List;
import org.lwjgl.LWJGLUtil;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Pattern;
import java.util.Map;

public class XRandR
{
    private static Screen[] current;
    private static Map<String, Screen[]> screens;
    private static final Pattern SCREEN_PATTERN1;
    private static final Pattern SCREEN_PATTERN2;
    
    private static void populate() {
        if (XRandR.screens == null) {
            XRandR.screens = new HashMap<String, Screen[]>();
            try {
                final Process p = Runtime.getRuntime().exec(new String[] { "xrandr", "-q" });
                final List<Screen> currentList = new ArrayList<Screen>();
                final List<Screen> possibles = new ArrayList<Screen>();
                String name = null;
                final BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line;
                while ((line = br.readLine()) != null) {
                    line = line.trim();
                    final String[] sa = line.split("\\s+");
                    if ("connected".equals(sa[1])) {
                        if (name != null) {
                            XRandR.screens.put(name, possibles.toArray(new Screen[possibles.size()]));
                            possibles.clear();
                        }
                        name = sa[0];
                        parseScreen(currentList, name, sa[2]);
                    }
                    else {
                        if (!Pattern.matches("\\d*x\\d*", sa[0])) {
                            continue;
                        }
                        parseScreen(possibles, name, sa[0]);
                    }
                }
                XRandR.screens.put(name, possibles.toArray(new Screen[possibles.size()]));
                XRandR.current = currentList.toArray(new Screen[currentList.size()]);
            }
            catch (final Throwable e) {
                LWJGLUtil.log("Exception in XRandR.populate(): " + e.getMessage());
                XRandR.screens.clear();
                XRandR.current = new Screen[0];
            }
        }
    }
    
    public static Screen[] getConfiguration() {
        populate();
        return XRandR.current.clone();
    }
    
    public static void setConfiguration(final Screen... screens) {
        if (screens.length == 0) {
            throw new IllegalArgumentException("Must specify at least one screen");
        }
        final List<String> cmd = new ArrayList<String>();
        cmd.add("xrandr");
        for (final Screen screen : XRandR.current) {
            boolean found = false;
            for (final Screen screen2 : screens) {
                if (screen2.name.equals(screen.name)) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                cmd.add("--output");
                cmd.add(screen.name);
                cmd.add("--off");
            }
        }
        for (final Screen screen : screens) {
            screen.getArgs(cmd);
        }
        try {
            final Process p = Runtime.getRuntime().exec(cmd.toArray(new String[cmd.size()]));
            final BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                LWJGLUtil.log("Unexpected output from xrandr process: " + line);
            }
            XRandR.current = screens;
        }
        catch (final IOException e) {
            LWJGLUtil.log("XRandR exception in setConfiguration(): " + e.getMessage());
        }
    }
    
    public static String[] getScreenNames() {
        populate();
        return XRandR.screens.keySet().toArray(new String[XRandR.screens.size()]);
    }
    
    public static Screen[] getResolutions(final String name) {
        populate();
        return XRandR.screens.get(name).clone();
    }
    
    private static void parseScreen(final List<Screen> list, final String name, final String what) {
        Matcher m = XRandR.SCREEN_PATTERN1.matcher(what);
        if (!m.matches()) {
            m = XRandR.SCREEN_PATTERN2.matcher(what);
            if (!m.matches()) {
                LWJGLUtil.log("Did not match: " + what);
                return;
            }
        }
        final int width = Integer.parseInt(m.group(1));
        final int height = Integer.parseInt(m.group(2));
        int xpos;
        int ypos;
        if (m.groupCount() > 3) {
            xpos = Integer.parseInt(m.group(3));
            ypos = Integer.parseInt(m.group(4));
        }
        else {
            xpos = 0;
            ypos = 0;
        }
        list.add(new Screen(name, width, height, xpos, ypos));
    }
    
    static {
        SCREEN_PATTERN1 = Pattern.compile("^(\\d+)x(\\d+)\\+(\\d+)\\+(\\d+)$");
        SCREEN_PATTERN2 = Pattern.compile("^(\\d+)x(\\d+)$");
    }
    
    public static class Screen implements Cloneable
    {
        public final String name;
        public final int width;
        public final int height;
        public int xPos;
        public int yPos;
        
        private Screen(final String name, final int width, final int height, final int xPos, final int yPos) {
            this.name = name;
            this.width = width;
            this.height = height;
            this.xPos = xPos;
            this.yPos = yPos;
        }
        
        private void getArgs(final List<String> argList) {
            argList.add("--output");
            argList.add(this.name);
            argList.add("--mode");
            argList.add(this.width + "x" + this.height);
            argList.add("--pos");
            argList.add(this.xPos + "x" + this.yPos);
        }
        
        @Override
        public String toString() {
            return this.name + " " + this.width + "x" + this.height + " @ " + this.xPos + "x" + this.yPos;
        }
    }
}
