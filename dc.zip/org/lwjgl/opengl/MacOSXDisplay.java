// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import org.lwjgl.BufferUtils;
import java.awt.Cursor;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.ArrayList;
import java.nio.FloatBuffer;
import java.awt.Window;
import java.security.PrivilegedAction;
import org.lwjgl.LWJGLException;
import java.awt.Component;
import org.lwjgl.LWJGLUtil;
import java.security.AccessController;
import com.apple.eawt.ApplicationListener;
import com.apple.eawt.ApplicationEvent;
import com.apple.eawt.ApplicationAdapter;
import com.apple.eawt.Application;
import java.security.PrivilegedExceptionAction;
import java.nio.IntBuffer;
import java.awt.DisplayMode;
import java.awt.Robot;
import java.awt.Canvas;

final class MacOSXDisplay implements DisplayImplementation
{
    private static final int PBUFFER_HANDLE_SIZE = 24;
    private static final int GAMMA_LENGTH = 256;
    private MacOSXCanvasListener canvas_listener;
    private MacOSXFrame frame;
    private Canvas canvas;
    private Robot robot;
    private MacOSXMouseEventQueue mouse_queue;
    private KeyboardEventQueue keyboard_queue;
    private DisplayMode requested_mode;
    private boolean close_requested;
    private static final IntBuffer current_viewport;
    
    MacOSXDisplay() {
        try {
            AccessController.doPrivileged((PrivilegedExceptionAction<Object>)new PrivilegedExceptionAction<Object>() {
                public Object run() throws Exception {
                    Application.getApplication().addApplicationListener((ApplicationListener)new ApplicationAdapter() {
                        public void handleQuit(final ApplicationEvent event) {
                            MacOSXDisplay.this.doHandleQuit();
                        }
                    });
                    return null;
                }
            });
        }
        catch (final Throwable e) {
            LWJGLUtil.log("Failed to register quit handler: " + e.getMessage());
        }
    }
    
    public void createWindow(final org.lwjgl.opengl.DisplayMode mode, final Canvas parent, final int x, final int y) throws LWJGLException {
        final boolean fullscreen = Display.isFullscreen();
        this.hideUI(fullscreen);
        this.close_requested = false;
        try {
            if (parent == null) {
                this.frame = new MacOSXFrame(mode, this.requested_mode, fullscreen, x, y);
                this.canvas = this.frame.getCanvas();
            }
            else {
                this.frame = null;
                this.canvas = parent;
            }
            this.canvas_listener = new MacOSXCanvasListener(this.canvas);
            this.robot = AWTUtil.createRobot(this.canvas);
        }
        catch (final LWJGLException e) {
            this.destroyWindow();
            throw e;
        }
    }
    
    private void doHandleQuit() {
        synchronized (this) {
            this.close_requested = true;
        }
    }
    
    public void destroyWindow() {
        if (this.canvas_listener != null) {
            this.canvas_listener.disableListeners();
            this.canvas_listener = null;
        }
        if (this.frame != null) {
            AccessController.doPrivileged((PrivilegedAction<Object>)new PrivilegedAction<Object>() {
                public Object run() {
                    if (MacOSXFrame.getDevice().getFullScreenWindow() == MacOSXDisplay.this.frame) {
                        MacOSXFrame.getDevice().setFullScreenWindow(null);
                    }
                    return null;
                }
            });
            if (this.frame.isDisplayable()) {
                this.frame.dispose();
            }
            this.frame = null;
        }
        this.hideUI(false);
    }
    
    public int getGammaRampLength() {
        return 256;
    }
    
    public native void setGammaRamp(final FloatBuffer p0) throws LWJGLException;
    
    public String getAdapter() {
        return null;
    }
    
    public String getVersion() {
        return null;
    }
    
    private static boolean equals(final DisplayMode awt_mode, final org.lwjgl.opengl.DisplayMode mode) {
        return awt_mode.getWidth() == mode.getWidth() && awt_mode.getHeight() == mode.getHeight() && awt_mode.getBitDepth() == mode.getBitsPerPixel() && awt_mode.getRefreshRate() == mode.getFrequency();
    }
    
    public void switchDisplayMode(final org.lwjgl.opengl.DisplayMode mode) throws LWJGLException {
        final DisplayMode[] arr$;
        final DisplayMode[] awt_modes = arr$ = MacOSXFrame.getDevice().getDisplayModes();
        for (final DisplayMode awt_mode : arr$) {
            if (equals(awt_mode, mode)) {
                this.requested_mode = awt_mode;
                return;
            }
        }
        throw new LWJGLException(mode + " is not supported");
    }
    
    public void resetDisplayMode() {
        if (MacOSXFrame.getDevice().getFullScreenWindow() != null) {
            MacOSXFrame.getDevice().setFullScreenWindow(null);
        }
        this.requested_mode = null;
        this.restoreGamma();
    }
    
    private native void restoreGamma();
    
    private static org.lwjgl.opengl.DisplayMode createLWJGLDisplayMode(final DisplayMode awt_mode) {
        final int awt_bit_depth = awt_mode.getBitDepth();
        final int awt_refresh_rate = awt_mode.getRefreshRate();
        int bit_depth;
        if (awt_bit_depth != -1) {
            bit_depth = awt_bit_depth;
        }
        else {
            bit_depth = 32;
        }
        int refresh_rate;
        if (awt_refresh_rate != 0) {
            refresh_rate = awt_refresh_rate;
        }
        else {
            refresh_rate = 0;
        }
        return new org.lwjgl.opengl.DisplayMode(awt_mode.getWidth(), awt_mode.getHeight(), bit_depth, refresh_rate);
    }
    
    public org.lwjgl.opengl.DisplayMode init() throws LWJGLException {
        return createLWJGLDisplayMode(MacOSXFrame.getDevice().getDisplayMode());
    }
    
    public org.lwjgl.opengl.DisplayMode[] getAvailableDisplayModes() throws LWJGLException {
        final DisplayMode[] awt_modes = MacOSXFrame.getDevice().getDisplayModes();
        final List<org.lwjgl.opengl.DisplayMode> modes = new ArrayList<org.lwjgl.opengl.DisplayMode>();
        for (final DisplayMode awt_mode : awt_modes) {
            if (awt_mode.getBitDepth() >= 16) {
                modes.add(createLWJGLDisplayMode(awt_mode));
            }
        }
        return modes.toArray(new org.lwjgl.opengl.DisplayMode[modes.size()]);
    }
    
    public void setTitle(final String title) {
        if (this.frame != null) {
            this.frame.setTitle(title);
        }
    }
    
    public boolean isCloseRequested() {
        final boolean result;
        synchronized (this) {
            result = (this.close_requested || (this.frame != null && this.frame.syncIsCloseRequested()));
            this.close_requested = false;
        }
        return result;
    }
    
    public boolean isVisible() {
        return this.frame == null || this.frame.syncIsVisible();
    }
    
    public boolean isActive() {
        return this.canvas.isFocusOwner();
    }
    
    public Canvas getCanvas() {
        return this.canvas;
    }
    
    public boolean isDirty() {
        return this.frame != null && this.frame.getCanvas().syncIsDirty();
    }
    
    public PeerInfo createPeerInfo(final PixelFormat pixel_format) throws LWJGLException {
        try {
            return new MacOSXDisplayPeerInfo(pixel_format, true);
        }
        catch (final LWJGLException e) {
            return new MacOSXDisplayPeerInfo(pixel_format, false);
        }
    }
    
    public void update() {
        final boolean should_update = this.canvas_listener.syncShouldUpdateContext();
        final AbstractDrawable drawable = (AbstractDrawable)Display.getDrawable();
        Label_0082: {
            if (Display.isFullscreen()) {
                if (this.frame == null || !this.frame.getCanvas().syncCanvasPainted()) {
                    if (!should_update) {
                        break Label_0082;
                    }
                }
                try {
                    MacOSXContextImplementation.resetView(drawable.peer_info, drawable.context);
                }
                catch (final LWJGLException e) {
                    LWJGLUtil.log("Failed to reset context: " + e);
                }
            }
        }
        if (should_update) {
            drawable.context.update();
            GL11.glGetInteger(2978, MacOSXDisplay.current_viewport);
            GL11.glViewport(MacOSXDisplay.current_viewport.get(0), MacOSXDisplay.current_viewport.get(1), MacOSXDisplay.current_viewport.get(2), MacOSXDisplay.current_viewport.get(3));
        }
        if (this.frame != null && this.mouse_queue != null) {
            if (this.frame.syncShouldReleaseCursor()) {
                MacOSXMouseEventQueue.nGrabMouse(false);
            }
            if (this.frame.syncShouldWarpCursor()) {
                this.mouse_queue.warpCursor();
            }
        }
    }
    
    private void hideUI(final boolean hide) {
        if (!LWJGLUtil.isMacOSXEqualsOrBetterThan(10, 4)) {
            this.nHideUI(hide);
        }
    }
    
    private native void nHideUI(final boolean p0);
    
    public void reshape(final int x, final int y, final int width, final int height) {
        if (this.frame != null) {
            this.frame.resize(x, y, width, height);
        }
    }
    
    public boolean hasWheel() {
        return AWTUtil.hasWheel();
    }
    
    public int getButtonCount() {
        return AWTUtil.getButtonCount();
    }
    
    public void createMouse() throws LWJGLException {
        (this.mouse_queue = new MacOSXMouseEventQueue(this.canvas)).register();
    }
    
    public void destroyMouse() {
        if (this.mouse_queue != null) {
            MacOSXMouseEventQueue.nGrabMouse(false);
            this.mouse_queue.unregister();
        }
        this.mouse_queue = null;
    }
    
    public void pollMouse(final IntBuffer coord_buffer, final ByteBuffer buttons_buffer) {
        this.mouse_queue.poll(coord_buffer, buttons_buffer);
    }
    
    public void readMouse(final ByteBuffer buffer) {
        this.mouse_queue.copyEvents(buffer);
    }
    
    public void grabMouse(final boolean grab) {
        this.mouse_queue.setGrabbed(grab);
    }
    
    public int getNativeCursorCapabilities() {
        return AWTUtil.getNativeCursorCapabilities();
    }
    
    public void setCursorPosition(final int x, final int y) {
        AWTUtil.setCursorPosition(this.canvas, this.robot, x, y);
    }
    
    public void setNativeCursor(final Object handle) throws LWJGLException {
        final Cursor awt_cursor = (Cursor)handle;
        if (this.frame != null) {
            this.frame.setCursor(awt_cursor);
        }
    }
    
    public int getMinCursorSize() {
        return AWTUtil.getMinCursorSize();
    }
    
    public int getMaxCursorSize() {
        return AWTUtil.getMaxCursorSize();
    }
    
    public void createKeyboard() throws LWJGLException {
        (this.keyboard_queue = new KeyboardEventQueue(this.canvas)).register();
    }
    
    public void destroyKeyboard() {
        if (this.keyboard_queue != null) {
            this.keyboard_queue.unregister();
        }
        this.keyboard_queue = null;
    }
    
    public void pollKeyboard(final ByteBuffer keyDownBuffer) {
        this.keyboard_queue.poll(keyDownBuffer);
    }
    
    public void readKeyboard(final ByteBuffer buffer) {
        this.keyboard_queue.copyEvents(buffer);
    }
    
    public Object createCursor(final int width, final int height, final int xHotspot, final int yHotspot, final int numImages, final IntBuffer images, final IntBuffer delays) throws LWJGLException {
        return AWTUtil.createCursor(width, height, xHotspot, yHotspot, numImages, images, delays);
    }
    
    public void destroyCursor(final Object cursor_handle) {
    }
    
    public int getPbufferCapabilities() {
        if (LWJGLUtil.isMacOSXEqualsOrBetterThan(10, 3)) {
            return 1;
        }
        return 0;
    }
    
    public boolean isBufferLost(final PeerInfo handle) {
        return false;
    }
    
    public PeerInfo createPbuffer(final int width, final int height, final PixelFormat pixel_format, final IntBuffer pixelFormatCaps, final IntBuffer pBufferAttribs) throws LWJGLException {
        return new MacOSXPbufferPeerInfo(width, height, pixel_format);
    }
    
    public void setPbufferAttrib(final PeerInfo handle, final int attrib, final int value) {
        throw new UnsupportedOperationException();
    }
    
    public void bindTexImageToPbuffer(final PeerInfo handle, final int buffer) {
        throw new UnsupportedOperationException();
    }
    
    public void releaseTexImageFromPbuffer(final PeerInfo handle, final int buffer) {
        throw new UnsupportedOperationException();
    }
    
    public int setIcon(final ByteBuffer[] icons) {
        return 0;
    }
    
    public int getWidth() {
        return Display.getDisplayMode().getWidth();
    }
    
    public int getHeight() {
        return Display.getDisplayMode().getHeight();
    }
    
    public boolean isInsideWindow() {
        return true;
    }
    
    static {
        current_viewport = BufferUtils.createIntBuffer(16);
    }
}
