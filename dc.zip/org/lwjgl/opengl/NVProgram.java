// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import java.nio.IntBuffer;
import java.nio.Buffer;
import org.lwjgl.BufferChecks;
import java.nio.ByteBuffer;

public class NVProgram
{
    public static final int GL_PROGRAM_TARGET_NV = 34374;
    public static final int GL_PROGRAM_LENGTH_NV = 34343;
    public static final int GL_PROGRAM_RESIDENT_NV = 34375;
    public static final int GL_PROGRAM_STRING_NV = 34344;
    public static final int GL_PROGRAM_ERROR_POSITION_NV = 34379;
    public static final int GL_PROGRAM_ERROR_STRING_NV = 34932;
    
    public static void glLoadProgramNV(final int target, final int programID, final ByteBuffer string) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glLoadProgramNV;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(string);
        nglLoadProgramNV(target, programID, string.remaining(), string, string.position(), function_pointer);
    }
    
    static native void nglLoadProgramNV(final int p0, final int p1, final int p2, final Buffer p3, final int p4, final long p5);
    
    public static void glLoadProgramNV(final int target, final int programID, final CharSequence string) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glLoadProgramNV;
        BufferChecks.checkFunctionAddress(function_pointer);
        nglLoadProgramNV(target, programID, string.length(), APIUtil.getBuffer(string), 0, function_pointer);
    }
    
    public static void glBindProgramNV(final int target, final int programID) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glBindProgramNV;
        BufferChecks.checkFunctionAddress(function_pointer);
        nglBindProgramNV(target, programID, function_pointer);
    }
    
    static native void nglBindProgramNV(final int p0, final int p1, final long p2);
    
    public static void glDeleteProgramsNV(final IntBuffer programs) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glDeleteProgramsNV;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(programs);
        nglDeleteProgramsNV(programs.remaining(), programs, programs.position(), function_pointer);
    }
    
    static native void nglDeleteProgramsNV(final int p0, final IntBuffer p1, final int p2, final long p3);
    
    public static void glDeleteProgramsNV(final int program) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glDeleteProgramsNV;
        BufferChecks.checkFunctionAddress(function_pointer);
        nglDeleteProgramsNV(1, APIUtil.getBufferInt().put(0, program), 0, function_pointer);
    }
    
    public static void glGenProgramsNV(final IntBuffer programs) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGenProgramsNV;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(programs);
        nglGenProgramsNV(programs.remaining(), programs, programs.position(), function_pointer);
    }
    
    static native void nglGenProgramsNV(final int p0, final IntBuffer p1, final int p2, final long p3);
    
    public static int glGenProgramsNV() {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGenProgramsNV;
        BufferChecks.checkFunctionAddress(function_pointer);
        final IntBuffer programs = APIUtil.getBufferInt();
        nglGenProgramsNV(1, programs, programs.position(), function_pointer);
        return programs.get(0);
    }
    
    public static void glGetProgramNV(final int programID, final int parameterName, final IntBuffer params) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGetProgramivNV;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(params);
        nglGetProgramivNV(programID, parameterName, params, params.position(), function_pointer);
    }
    
    static native void nglGetProgramivNV(final int p0, final int p1, final IntBuffer p2, final int p3, final long p4);
    
    public static int glGetProgramNV(final int programID, final int parameterName) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGetProgramivNV;
        BufferChecks.checkFunctionAddress(function_pointer);
        final IntBuffer params = APIUtil.getBufferInt();
        nglGetProgramivNV(programID, parameterName, params, params.position(), function_pointer);
        return params.get(0);
    }
    
    public static void glGetProgramStringNV(final int programID, final int parameterName, final ByteBuffer paramString) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGetProgramStringNV;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(paramString);
        nglGetProgramStringNV(programID, parameterName, paramString, paramString.position(), function_pointer);
    }
    
    static native void nglGetProgramStringNV(final int p0, final int p1, final Buffer p2, final int p3, final long p4);
    
    public static String glGetProgramStringNV(final int programID, final int parameterName) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGetProgramStringNV;
        BufferChecks.checkFunctionAddress(function_pointer);
        final int programLength = glGetProgramNV(programID, 34343);
        final ByteBuffer paramString = APIUtil.getBufferByte(programLength);
        nglGetProgramStringNV(programID, parameterName, paramString, paramString.position(), function_pointer);
        paramString.limit(programLength);
        return APIUtil.getString(paramString);
    }
    
    public static boolean glIsProgramNV(final int programID) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glIsProgramNV;
        BufferChecks.checkFunctionAddress(function_pointer);
        final boolean __result = nglIsProgramNV(programID, function_pointer);
        return __result;
    }
    
    static native boolean nglIsProgramNV(final int p0, final long p1);
    
    public static boolean glAreProgramsResidentNV(final IntBuffer programIDs, final ByteBuffer programResidences) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glAreProgramsResidentNV;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(programIDs);
        BufferChecks.checkBuffer(programResidences, programIDs.remaining());
        final boolean __result = nglAreProgramsResidentNV(programIDs.remaining(), programIDs, programIDs.position(), programResidences, programResidences.position(), function_pointer);
        return __result;
    }
    
    static native boolean nglAreProgramsResidentNV(final int p0, final IntBuffer p1, final int p2, final ByteBuffer p3, final int p4, final long p5);
    
    public static void glRequestResidentProgramsNV(final IntBuffer programIDs) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glRequestResidentProgramsNV;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(programIDs);
        nglRequestResidentProgramsNV(programIDs.remaining(), programIDs, programIDs.position(), function_pointer);
    }
    
    static native void nglRequestResidentProgramsNV(final int p0, final IntBuffer p1, final int p2, final long p3);
    
    public static void glRequestResidentProgramsNV(final int programID) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glRequestResidentProgramsNV;
        BufferChecks.checkFunctionAddress(function_pointer);
        nglRequestResidentProgramsNV(1, APIUtil.getBufferInt().put(0, programID), 0, function_pointer);
    }
}
