// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import org.lwjgl.BufferUtils;
import java.nio.Buffer;
import org.lwjgl.LWJGLUtil;

class GLChecks
{
    private GLChecks() {
    }
    
    static References getReferences(final ContextCapabilities caps) {
        return StateTracker.getReferencesStack(caps).getReferences();
    }
    
    static int getBufferObjectSize(final ContextCapabilities caps, final int buffer_enum) {
        return GL15.glGetBufferParameter(buffer_enum, 34660);
    }
    
    static int getBufferObjectSizeARB(final ContextCapabilities caps, final int buffer_enum) {
        return ARBBufferObject.glGetBufferParameterARB(buffer_enum, 34660);
    }
    
    static int getBufferObjectSizeATI(final ContextCapabilities caps, final int buffer) {
        return ATIVertexArrayObject.glGetObjectBufferATI(buffer, 34660);
    }
    
    static int getNamedBufferObjectSize(final ContextCapabilities caps, final int buffer) {
        return EXTDirectStateAccess.glGetNamedBufferParameterEXT(buffer, 34660);
    }
    
    static void ensureArrayVBOdisabled(final ContextCapabilities caps) {
        if (LWJGLUtil.CHECKS && StateTracker.getReferencesStack(caps).getReferences().arrayBuffer != 0) {
            throw new OpenGLException("Cannot use Buffers when Array Buffer Object is enabled");
        }
    }
    
    static void ensureArrayVBOenabled(final ContextCapabilities caps) {
        if (LWJGLUtil.CHECKS && StateTracker.getReferencesStack(caps).getReferences().arrayBuffer == 0) {
            throw new OpenGLException("Cannot use offsets when Array Buffer Object is disabled");
        }
    }
    
    static void ensureElementVBOdisabled(final ContextCapabilities caps) {
        if (LWJGLUtil.CHECKS && StateTracker.getReferencesStack(caps).getReferences().elementArrayBuffer != 0) {
            throw new OpenGLException("Cannot use Buffers when Element Array Buffer Object is enabled");
        }
    }
    
    static void ensureElementVBOenabled(final ContextCapabilities caps) {
        if (LWJGLUtil.CHECKS && StateTracker.getReferencesStack(caps).getReferences().elementArrayBuffer == 0) {
            throw new OpenGLException("Cannot use offsets when Element Array Buffer Object is disabled");
        }
    }
    
    static void ensureIndirectBOdisabled(final ContextCapabilities caps) {
        if (LWJGLUtil.CHECKS && StateTracker.getReferencesStack(caps).getReferences().indirectBuffer != 0) {
            throw new OpenGLException("Cannot use Buffers when Draw Indirect Object is enabled");
        }
    }
    
    static void ensureIndirectBOenabled(final ContextCapabilities caps) {
        if (LWJGLUtil.CHECKS && StateTracker.getReferencesStack(caps).getReferences().indirectBuffer == 0) {
            throw new OpenGLException("Cannot use offsets when Draw Indirect Object is disabled");
        }
    }
    
    static void ensurePackPBOdisabled(final ContextCapabilities caps) {
        if (LWJGLUtil.CHECKS && StateTracker.getReferencesStack(caps).getReferences().pixelPackBuffer != 0) {
            throw new OpenGLException("Cannot use Buffers when Pixel Pack Buffer Object is enabled");
        }
    }
    
    static void ensurePackPBOenabled(final ContextCapabilities caps) {
        if (LWJGLUtil.CHECKS && StateTracker.getReferencesStack(caps).getReferences().pixelPackBuffer == 0) {
            throw new OpenGLException("Cannot use offsets when Pixel Pack Buffer Object is disabled");
        }
    }
    
    static void ensureUnpackPBOdisabled(final ContextCapabilities caps) {
        if (LWJGLUtil.CHECKS && StateTracker.getReferencesStack(caps).getReferences().pixelUnpackBuffer != 0) {
            throw new OpenGLException("Cannot use Buffers when Pixel Unpack Buffer Object is enabled");
        }
    }
    
    static void ensureUnpackPBOenabled(final ContextCapabilities caps) {
        if (LWJGLUtil.CHECKS && StateTracker.getReferencesStack(caps).getReferences().pixelUnpackBuffer == 0) {
            throw new OpenGLException("Cannot use offsets when Pixel Unpack Buffer Object is disabled");
        }
    }
    
    static int calculateImageStorage(final Buffer buffer, final int format, final int type, final int width, final int height, final int depth) {
        return LWJGLUtil.CHECKS ? (calculateImageStorage(format, type, width, height, depth) >> BufferUtils.getElementSizeExponent(buffer)) : 0;
    }
    
    static int calculateTexImage1DStorage(final Buffer buffer, final int format, final int type, final int width) {
        return LWJGLUtil.CHECKS ? (calculateTexImage1DStorage(format, type, width) >> BufferUtils.getElementSizeExponent(buffer)) : 0;
    }
    
    static int calculateTexImage2DStorage(final Buffer buffer, final int format, final int type, final int width, final int height) {
        return LWJGLUtil.CHECKS ? (calculateTexImage2DStorage(format, type, width, height) >> BufferUtils.getElementSizeExponent(buffer)) : 0;
    }
    
    static int calculateTexImage3DStorage(final Buffer buffer, final int format, final int type, final int width, final int height, final int depth) {
        return LWJGLUtil.CHECKS ? (calculateTexImage3DStorage(format, type, width, height, depth) >> BufferUtils.getElementSizeExponent(buffer)) : 0;
    }
    
    private static int calculateImageStorage(final int format, final int type, final int width, final int height, final int depth) {
        return calculateBytesPerPixel(format, type) * width * height * depth;
    }
    
    private static int calculateTexImage1DStorage(final int format, final int type, final int width) {
        return calculateBytesPerPixel(format, type) * width;
    }
    
    private static int calculateTexImage2DStorage(final int format, final int type, final int width, final int height) {
        return calculateTexImage1DStorage(format, type, width) * height;
    }
    
    private static int calculateTexImage3DStorage(final int format, final int type, final int width, final int height, final int depth) {
        return calculateTexImage2DStorage(format, type, width, height) * depth;
    }
    
    private static int calculateBytesPerPixel(final int format, final int type) {
        int bpe = 0;
        switch (type) {
            case 5120:
            case 5121: {
                bpe = 1;
                break;
            }
            case 5122:
            case 5123: {
                bpe = 2;
                break;
            }
            case 5124:
            case 5125:
            case 5126: {
                bpe = 4;
                break;
            }
            default: {
                return 0;
            }
        }
        int epp = 0;
        switch (format) {
            case 6406:
            case 6409: {
                epp = 1;
                break;
            }
            case 6410: {
                epp = 2;
                break;
            }
            case 6407:
            case 32992: {
                epp = 3;
                break;
            }
            case 6408:
            case 32768:
            case 32993: {
                epp = 4;
                break;
            }
            default: {
                return 0;
            }
        }
        return bpe * epp;
    }
}
