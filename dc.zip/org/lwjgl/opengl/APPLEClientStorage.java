// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class APPLEClientStorage
{
    public static final int GL_UNPACK_CLIENT_STORAGE_APPLE = 34226;
    
    private APPLEClientStorage() {
    }
}
