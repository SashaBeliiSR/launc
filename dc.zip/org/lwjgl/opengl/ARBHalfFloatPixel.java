// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class ARBHalfFloatPixel
{
    public static final int GL_HALF_FLOAT_ARB = 5131;
    
    private ARBHalfFloatPixel() {
    }
}
