// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class ARBPointSprite
{
    public static final int GL_POINT_SPRITE_ARB = 34913;
    public static final int GL_COORD_REPLACE_ARB = 34914;
    
    private ARBPointSprite() {
    }
}
