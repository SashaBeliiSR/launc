// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import java.util.Iterator;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.io.IOException;
import java.util.List;
import org.lwjgl.BufferUtils;
import java.nio.IntBuffer;
import java.nio.FloatBuffer;
import java.security.AccessController;
import java.security.PrivilegedAction;
import org.lwjgl.LWJGLUtil;
import org.lwjgl.LWJGLException;
import java.awt.Canvas;
import java.nio.ByteBuffer;

final class LinuxDisplay implements DisplayImplementation
{
    public static final int CurrentTime = 0;
    public static final int GrabSuccess = 0;
    public static final int AutoRepeatModeOff = 0;
    public static final int AutoRepeatModeOn = 1;
    public static final int AutoRepeatModeDefault = 2;
    public static final int None = 0;
    private static final int KeyPressMask = 1;
    private static final int KeyReleaseMask = 2;
    private static final int ButtonPressMask = 4;
    private static final int ButtonReleaseMask = 8;
    private static final int NotifyAncestor = 0;
    private static final int NotifyNonlinear = 3;
    private static final int NotifyPointer = 5;
    private static final int NotifyPointerRoot = 6;
    private static final int NotifyDetailNone = 7;
    private static final int SetModeInsert = 0;
    private static final int SaveSetRoot = 1;
    private static final int SaveSetUnmap = 1;
    private static final int FULLSCREEN_LEGACY = 1;
    private static final int FULLSCREEN_NETWM = 2;
    private static final int WINDOWED = 3;
    private static int current_window_mode;
    private static final int XRANDR = 10;
    private static final int XF86VIDMODE = 11;
    private static final int NONE = 12;
    private static long display;
    private static long current_window;
    private static long saved_error_handler;
    private static int display_connection_usage_count;
    private final LinuxEvent event_buffer;
    private final LinuxEvent tmp_event_buffer;
    private int current_displaymode_extension;
    private long delete_atom;
    private PeerInfo peer_info;
    private ByteBuffer saved_gamma;
    private ByteBuffer current_gamma;
    private DisplayMode saved_mode;
    private DisplayMode current_mode;
    private XRandR.Screen[] savedXrandrConfig;
    private boolean keyboard_grabbed;
    private boolean pointer_grabbed;
    private boolean input_released;
    private boolean grab;
    private boolean focused;
    private boolean minimized;
    private boolean dirty;
    private boolean close_requested;
    private long current_cursor;
    private long blank_cursor;
    private Canvas parent;
    private long parent_window;
    private boolean xembedded;
    private boolean parent_focus;
    private LinuxKeyboard keyboard;
    private LinuxMouse mouse;
    
    LinuxDisplay() {
        this.event_buffer = new LinuxEvent();
        this.tmp_event_buffer = new LinuxEvent();
        this.current_displaymode_extension = 12;
    }
    
    private static ByteBuffer getCurrentGammaRamp() throws LWJGLException {
        lockAWT();
        try {
            incDisplay();
            try {
                if (isXF86VidModeSupported()) {
                    return nGetCurrentGammaRamp(getDisplay(), getDefaultScreen());
                }
                return null;
            }
            finally {
                decDisplay();
            }
        }
        finally {
            unlockAWT();
        }
    }
    
    private static native ByteBuffer nGetCurrentGammaRamp(final long p0, final int p1) throws LWJGLException;
    
    private static int getBestDisplayModeExtension() {
        int result;
        if (isXrandrSupported()) {
            LWJGLUtil.log("Using Xrandr for display mode switching");
            result = 10;
        }
        else if (isXF86VidModeSupported()) {
            LWJGLUtil.log("Using XF86VidMode for display mode switching");
            result = 11;
        }
        else {
            LWJGLUtil.log("No display mode extensions available");
            result = 12;
        }
        return result;
    }
    
    private static boolean isXrandrSupported() {
        if (Display.getPrivilegedBoolean("LWJGL_DISABLE_XRANDR")) {
            return false;
        }
        lockAWT();
        try {
            incDisplay();
            try {
                return nIsXrandrSupported(getDisplay());
            }
            finally {
                decDisplay();
            }
        }
        catch (final LWJGLException e) {
            LWJGLUtil.log("Got exception while querying Xrandr support: " + e);
            return false;
        }
        finally {
            unlockAWT();
        }
    }
    
    private static native boolean nIsXrandrSupported(final long p0) throws LWJGLException;
    
    private static boolean isXF86VidModeSupported() {
        lockAWT();
        try {
            incDisplay();
            try {
                return nIsXF86VidModeSupported(getDisplay());
            }
            finally {
                decDisplay();
            }
        }
        catch (final LWJGLException e) {
            LWJGLUtil.log("Got exception while querying XF86VM support: " + e);
            return false;
        }
        finally {
            unlockAWT();
        }
    }
    
    private static native boolean nIsXF86VidModeSupported(final long p0) throws LWJGLException;
    
    private static boolean isNetWMFullscreenSupported() throws LWJGLException {
        if (Display.getPrivilegedBoolean("LWJGL_DISABLE_NETWM")) {
            return false;
        }
        lockAWT();
        try {
            incDisplay();
            try {
                return nIsNetWMFullscreenSupported(getDisplay(), getDefaultScreen());
            }
            finally {
                decDisplay();
            }
        }
        catch (final LWJGLException e) {
            LWJGLUtil.log("Got exception while querying NetWM support: " + e);
            return false;
        }
        finally {
            unlockAWT();
        }
    }
    
    private static native boolean nIsNetWMFullscreenSupported(final long p0, final int p1) throws LWJGLException;
    
    static void lockAWT() {
        try {
            nLockAWT();
        }
        catch (final LWJGLException e) {
            LWJGLUtil.log("Caught exception while locking AWT: " + e);
        }
    }
    
    private static native void nLockAWT() throws LWJGLException;
    
    static void unlockAWT() {
        try {
            nUnlockAWT();
        }
        catch (final LWJGLException e) {
            LWJGLUtil.log("Caught exception while unlocking AWT: " + e);
        }
    }
    
    private static native void nUnlockAWT() throws LWJGLException;
    
    static void incDisplay() throws LWJGLException {
        if (LinuxDisplay.display_connection_usage_count == 0) {
            GLContext.loadOpenGLLibrary();
            LinuxDisplay.saved_error_handler = setErrorHandler();
            LinuxDisplay.display = openDisplay();
        }
        ++LinuxDisplay.display_connection_usage_count;
    }
    
    private static native int callErrorHandler(final long p0, final long p1, final long p2);
    
    private static native long setErrorHandler();
    
    private static native long resetErrorHandler(final long p0);
    
    private static native void synchronize(final long p0, final boolean p1);
    
    private static int globalErrorHandler(final long display, final long event_ptr, final long error_display, final long serial, final long error_code, final long request_code, final long minor_code) throws LWJGLException {
        if (display == getDisplay()) {
            final String error_msg = getErrorText(display, error_code);
            throw new LWJGLException("X Error - disp: 0x" + Long.toHexString(error_display) + " serial: " + serial + " error: " + error_msg + " request_code: " + request_code + " minor_code: " + minor_code);
        }
        if (LinuxDisplay.saved_error_handler != 0L) {
            return callErrorHandler(LinuxDisplay.saved_error_handler, display, event_ptr);
        }
        return 0;
    }
    
    private static native String getErrorText(final long p0, final long p1);
    
    static void decDisplay() {
    }
    
    static native long openDisplay() throws LWJGLException;
    
    static native void closeDisplay(final long p0);
    
    private int getWindowMode(final boolean fullscreen) throws LWJGLException {
        if (!fullscreen) {
            return 3;
        }
        if (this.current_displaymode_extension == 10 && isNetWMFullscreenSupported()) {
            LWJGLUtil.log("Using NetWM for fullscreen window");
            return 2;
        }
        LWJGLUtil.log("Using legacy mode for fullscreen window");
        return 1;
    }
    
    static long getDisplay() {
        if (LinuxDisplay.display_connection_usage_count <= 0) {
            throw new InternalError("display_connection_usage_count = " + LinuxDisplay.display_connection_usage_count);
        }
        return LinuxDisplay.display;
    }
    
    static int getDefaultScreen() {
        return nGetDefaultScreen(getDisplay());
    }
    
    static native int nGetDefaultScreen(final long p0);
    
    static long getWindow() {
        return LinuxDisplay.current_window;
    }
    
    private void ungrabKeyboard() {
        if (this.keyboard_grabbed) {
            nUngrabKeyboard(getDisplay());
            this.keyboard_grabbed = false;
        }
    }
    
    static native int nUngrabKeyboard(final long p0);
    
    private void grabKeyboard() {
        if (!this.keyboard_grabbed) {
            final int res = nGrabKeyboard(getDisplay(), getWindow());
            if (res == 0) {
                this.keyboard_grabbed = true;
            }
        }
    }
    
    static native int nGrabKeyboard(final long p0, final long p1);
    
    private void grabPointer() {
        if (!this.pointer_grabbed) {
            final int result = nGrabPointer(getDisplay(), getWindow(), 0L);
            if (result == 0) {
                this.pointer_grabbed = true;
                if (isLegacyFullscreen()) {
                    nSetViewPort(getDisplay(), getWindow(), getDefaultScreen());
                }
            }
        }
    }
    
    static native int nGrabPointer(final long p0, final long p1, final long p2);
    
    private static native void nSetViewPort(final long p0, final long p1, final int p2);
    
    private void ungrabPointer() {
        if (this.pointer_grabbed) {
            this.pointer_grabbed = false;
            nUngrabPointer(getDisplay());
        }
    }
    
    static native int nUngrabPointer(final long p0);
    
    private static boolean isFullscreen() {
        return LinuxDisplay.current_window_mode == 1 || LinuxDisplay.current_window_mode == 2;
    }
    
    private boolean shouldGrab() {
        return !this.input_released && this.grab && this.mouse != null;
    }
    
    private void updatePointerGrab() {
        if (isFullscreen() || this.shouldGrab()) {
            this.grabPointer();
        }
        else {
            this.ungrabPointer();
        }
        this.updateCursor();
    }
    
    private void updateCursor() {
        long cursor;
        if (this.shouldGrab()) {
            cursor = this.blank_cursor;
        }
        else {
            cursor = this.current_cursor;
        }
        nDefineCursor(getDisplay(), getWindow(), cursor);
    }
    
    private static native void nDefineCursor(final long p0, final long p1, final long p2);
    
    private static boolean isLegacyFullscreen() {
        return LinuxDisplay.current_window_mode == 1;
    }
    
    private void updateKeyboardGrab() {
        if (isLegacyFullscreen()) {
            this.grabKeyboard();
        }
        else {
            this.ungrabKeyboard();
        }
    }
    
    public void createWindow(final DisplayMode mode, final Canvas parent, final int x, final int y) throws LWJGLException {
        lockAWT();
        try {
            incDisplay();
            try {
                final ByteBuffer handle = this.peer_info.lockAndGetHandle();
                try {
                    LinuxDisplay.current_window_mode = this.getWindowMode(Display.isFullscreen());
                    if (LinuxDisplay.current_window_mode != 3) {
                        Compiz.setLegacyFullscreenSupport(true);
                    }
                    final boolean undecorated = Display.getPrivilegedBoolean("org.lwjgl.opengl.Window.undecorated") || (LinuxDisplay.current_window_mode != 3 && Display.getPrivilegedBoolean("org.lwjgl.opengl.Window.undecorated_fs"));
                    this.parent = parent;
                    this.parent_window = ((parent != null) ? getHandle(parent) : getRootWindow(getDisplay(), getDefaultScreen()));
                    LinuxDisplay.current_window = nCreateWindow(getDisplay(), getDefaultScreen(), handle, mode, LinuxDisplay.current_window_mode, x, y, undecorated, this.parent_window);
                    mapRaised(getDisplay(), LinuxDisplay.current_window);
                    this.xembedded = (parent != null && isAncestorXEmbedded(this.parent_window));
                    this.blank_cursor = createBlankCursor();
                    this.current_cursor = 0L;
                    this.focused = false;
                    this.input_released = false;
                    this.pointer_grabbed = false;
                    this.keyboard_grabbed = false;
                    this.close_requested = false;
                    this.grab = false;
                    this.minimized = false;
                    this.dirty = true;
                }
                finally {
                    this.peer_info.unlock();
                }
            }
            catch (final LWJGLException e) {
                decDisplay();
                throw e;
            }
        }
        finally {
            unlockAWT();
        }
    }
    
    private static native long nCreateWindow(final long p0, final int p1, final ByteBuffer p2, final DisplayMode p3, final int p4, final int p5, final int p6, final boolean p7, final long p8) throws LWJGLException;
    
    private static native long getRootWindow(final long p0, final int p1);
    
    private static native boolean hasProperty(final long p0, final long p1, final long p2);
    
    private static native long getParentWindow(final long p0, final long p1) throws LWJGLException;
    
    private static native void mapRaised(final long p0, final long p1);
    
    private static native void reparentWindow(final long p0, final long p1, final long p2, final int p3, final int p4);
    
    private static boolean isAncestorXEmbedded(final long window) throws LWJGLException {
        final long xembed_atom = internAtom("_XEMBED_INFO", true);
        if (xembed_atom != 0L) {
            for (long w = window; w != 0L; w = getParentWindow(getDisplay(), w)) {
                if (hasProperty(getDisplay(), w, xembed_atom)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private static long getHandle(final Canvas parent) throws LWJGLException {
        final AWTCanvasImplementation awt_impl = AWTGLCanvas.createImplementation();
        final LinuxPeerInfo parent_peer_info = (LinuxPeerInfo)awt_impl.createPeerInfo(parent, null);
        final ByteBuffer parent_peer_info_handle = parent_peer_info.lockAndGetHandle();
        try {
            return parent_peer_info.getDrawable();
        }
        finally {
            parent_peer_info.unlock();
        }
    }
    
    private void updateInputGrab() {
        this.updatePointerGrab();
        this.updateKeyboardGrab();
    }
    
    public void destroyWindow() {
        lockAWT();
        try {
            try {
                this.setNativeCursor(null);
            }
            catch (final LWJGLException e) {
                LWJGLUtil.log("Failed to reset cursor: " + e.getMessage());
            }
            nDestroyCursor(getDisplay(), this.blank_cursor);
            this.blank_cursor = 0L;
            this.ungrabKeyboard();
            nDestroyWindow(getDisplay(), getWindow());
            decDisplay();
            if (LinuxDisplay.current_window_mode != 3) {
                Compiz.setLegacyFullscreenSupport(false);
            }
        }
        finally {
            unlockAWT();
        }
    }
    
    static native void nDestroyWindow(final long p0, final long p1);
    
    public void switchDisplayMode(final DisplayMode mode) throws LWJGLException {
        lockAWT();
        try {
            this.switchDisplayModeOnTmpDisplay(mode);
            this.current_mode = mode;
        }
        finally {
            unlockAWT();
        }
    }
    
    private void switchDisplayModeOnTmpDisplay(final DisplayMode mode) throws LWJGLException {
        incDisplay();
        try {
            nSwitchDisplayMode(getDisplay(), getDefaultScreen(), this.current_displaymode_extension, mode);
        }
        finally {
            decDisplay();
        }
    }
    
    private static native void nSwitchDisplayMode(final long p0, final int p1, final int p2, final DisplayMode p3) throws LWJGLException;
    
    private static long internAtom(final String atom_name, final boolean only_if_exists) throws LWJGLException {
        incDisplay();
        try {
            return nInternAtom(getDisplay(), atom_name, only_if_exists);
        }
        finally {
            decDisplay();
        }
    }
    
    static native long nInternAtom(final long p0, final String p1, final boolean p2);
    
    public void resetDisplayMode() {
        lockAWT();
        try {
            if (this.current_displaymode_extension == 10 && this.savedXrandrConfig.length > 0) {
                AccessController.doPrivileged((PrivilegedAction<Object>)new PrivilegedAction<Object>() {
                    public Object run() {
                        XRandR.setConfiguration(LinuxDisplay.this.savedXrandrConfig);
                        return null;
                    }
                });
            }
            else {
                this.switchDisplayMode(this.saved_mode);
            }
            if (isXF86VidModeSupported()) {
                this.doSetGamma(this.saved_gamma);
            }
            Compiz.setLegacyFullscreenSupport(false);
        }
        catch (final LWJGLException e) {
            LWJGLUtil.log("Caught exception while resetting mode: " + e);
        }
        finally {
            unlockAWT();
        }
    }
    
    public int getGammaRampLength() {
        if (!isXF86VidModeSupported()) {
            return 0;
        }
        lockAWT();
        try {
            incDisplay();
            try {
                return nGetGammaRampLength(getDisplay(), getDefaultScreen());
            }
            catch (final LWJGLException e) {
                LWJGLUtil.log("Got exception while querying gamma length: " + e);
                return 0;
            }
            finally {
                decDisplay();
            }
        }
        catch (final LWJGLException e) {
            LWJGLUtil.log("Failed to get gamma ramp length: " + e);
            return 0;
        }
        finally {
            unlockAWT();
        }
    }
    
    private static native int nGetGammaRampLength(final long p0, final int p1) throws LWJGLException;
    
    public void setGammaRamp(final FloatBuffer gammaRamp) throws LWJGLException {
        if (!isXF86VidModeSupported()) {
            throw new LWJGLException("No gamma ramp support (Missing XF86VM extension)");
        }
        this.doSetGamma(convertToNativeRamp(gammaRamp));
    }
    
    private void doSetGamma(final ByteBuffer native_gamma) throws LWJGLException {
        lockAWT();
        try {
            setGammaRampOnTmpDisplay(native_gamma);
            this.current_gamma = native_gamma;
        }
        finally {
            unlockAWT();
        }
    }
    
    private static void setGammaRampOnTmpDisplay(final ByteBuffer native_gamma) throws LWJGLException {
        incDisplay();
        try {
            nSetGammaRamp(getDisplay(), getDefaultScreen(), native_gamma);
        }
        finally {
            decDisplay();
        }
    }
    
    private static native void nSetGammaRamp(final long p0, final int p1, final ByteBuffer p2) throws LWJGLException;
    
    private static ByteBuffer convertToNativeRamp(final FloatBuffer ramp) throws LWJGLException {
        return nConvertToNativeRamp(ramp, ramp.position(), ramp.remaining());
    }
    
    private static native ByteBuffer nConvertToNativeRamp(final FloatBuffer p0, final int p1, final int p2) throws LWJGLException;
    
    public String getAdapter() {
        return null;
    }
    
    public String getVersion() {
        return null;
    }
    
    public DisplayMode init() throws LWJGLException {
        lockAWT();
        try {
            Compiz.init();
            this.delete_atom = internAtom("WM_DELETE_WINDOW", false);
            this.current_displaymode_extension = getBestDisplayModeExtension();
            if (this.current_displaymode_extension == 12) {
                throw new LWJGLException("No display mode extension is available");
            }
            final DisplayMode[] modes = this.getAvailableDisplayModes();
            if (modes == null || modes.length == 0) {
                throw new LWJGLException("No modes available");
            }
            switch (this.current_displaymode_extension) {
                case 10: {
                    this.savedXrandrConfig = AccessController.doPrivileged((PrivilegedAction<XRandR.Screen[]>)new PrivilegedAction<XRandR.Screen[]>() {
                        public XRandR.Screen[] run() {
                            return XRandR.getConfiguration();
                        }
                    });
                    this.saved_mode = getCurrentXRandrMode();
                    break;
                }
                case 11: {
                    this.saved_mode = modes[0];
                    break;
                }
                default: {
                    throw new LWJGLException("Unknown display mode extension: " + this.current_displaymode_extension);
                }
            }
            this.current_mode = this.saved_mode;
            this.saved_gamma = getCurrentGammaRamp();
            this.current_gamma = this.saved_gamma;
            return this.saved_mode;
        }
        finally {
            unlockAWT();
        }
    }
    
    private static DisplayMode getCurrentXRandrMode() throws LWJGLException {
        lockAWT();
        try {
            incDisplay();
            try {
                return nGetCurrentXRandrMode(getDisplay(), getDefaultScreen());
            }
            finally {
                decDisplay();
            }
        }
        finally {
            unlockAWT();
        }
    }
    
    private static native DisplayMode nGetCurrentXRandrMode(final long p0, final int p1) throws LWJGLException;
    
    public void setTitle(final String title) {
        lockAWT();
        try {
            nSetTitle(getDisplay(), getWindow(), title);
        }
        finally {
            unlockAWT();
        }
    }
    
    private static native void nSetTitle(final long p0, final long p1, final String p2);
    
    public boolean isCloseRequested() {
        final boolean result = this.close_requested;
        this.close_requested = false;
        return result;
    }
    
    public boolean isVisible() {
        return !this.minimized;
    }
    
    public boolean isActive() {
        return this.focused || isLegacyFullscreen();
    }
    
    public boolean isDirty() {
        final boolean result = this.dirty;
        this.dirty = false;
        return result;
    }
    
    public PeerInfo createPeerInfo(final PixelFormat pixel_format) throws LWJGLException {
        return this.peer_info = new LinuxDisplayPeerInfo(pixel_format);
    }
    
    static native void setInputFocus(final long p0, final long p1, final long p2);
    
    private void relayEventToParent(final LinuxEvent event_buffer, final int event_mask) {
        this.tmp_event_buffer.copyFrom(event_buffer);
        this.tmp_event_buffer.setWindow(this.parent_window);
        this.tmp_event_buffer.sendEvent(getDisplay(), this.parent_window, true, event_mask);
    }
    
    private void relayEventToParent(final LinuxEvent event_buffer) {
        if (this.parent == null) {
            return;
        }
        switch (event_buffer.getType()) {
            case 2: {
                this.relayEventToParent(event_buffer, 1);
                break;
            }
            case 3: {
                this.relayEventToParent(event_buffer, 1);
                break;
            }
            case 4: {
                this.relayEventToParent(event_buffer, 1);
                break;
            }
            case 5: {
                this.relayEventToParent(event_buffer, 1);
                break;
            }
        }
    }
    
    private void processEvents() {
        while (LinuxEvent.getPending(getDisplay()) > 0) {
            this.event_buffer.nextEvent(getDisplay());
            final long event_window = this.event_buffer.getWindow();
            this.relayEventToParent(this.event_buffer);
            if (event_window == getWindow() && !this.event_buffer.filterEvent(event_window) && (this.mouse == null || !this.mouse.filterEvent(this.grab, this.shouldWarpPointer(), this.event_buffer))) {
                if (this.keyboard != null && this.keyboard.filterEvent(this.event_buffer)) {
                    continue;
                }
                switch (this.event_buffer.getType()) {
                    case 9: {
                        this.setFocused(true, this.event_buffer.getFocusDetail());
                        continue;
                    }
                    case 10: {
                        this.setFocused(false, this.event_buffer.getFocusDetail());
                        continue;
                    }
                    case 33: {
                        if (this.event_buffer.getClientFormat() == 32 && this.event_buffer.getClientData(0) == this.delete_atom) {
                            this.close_requested = true;
                            continue;
                        }
                        continue;
                    }
                    case 19: {
                        this.dirty = true;
                        this.minimized = false;
                        continue;
                    }
                    case 18: {
                        this.dirty = true;
                        this.minimized = true;
                        continue;
                    }
                    case 12: {
                        this.dirty = true;
                        continue;
                    }
                }
            }
        }
    }
    
    public void update() {
        lockAWT();
        try {
            this.processEvents();
            this.checkInput();
        }
        finally {
            unlockAWT();
        }
    }
    
    public void reshape(final int x, final int y, final int width, final int height) {
        lockAWT();
        try {
            nReshape(getDisplay(), getWindow(), x, y, width, height);
        }
        finally {
            unlockAWT();
        }
    }
    
    private static native void nReshape(final long p0, final long p1, final int p2, final int p3, final int p4, final int p5);
    
    public DisplayMode[] getAvailableDisplayModes() throws LWJGLException {
        lockAWT();
        try {
            incDisplay();
            try {
                final DisplayMode[] modes = nGetAvailableDisplayModes(getDisplay(), getDefaultScreen(), this.current_displaymode_extension);
                return modes;
            }
            finally {
                decDisplay();
            }
        }
        finally {
            unlockAWT();
        }
    }
    
    private static native DisplayMode[] nGetAvailableDisplayModes(final long p0, final int p1, final int p2) throws LWJGLException;
    
    public boolean hasWheel() {
        return true;
    }
    
    public int getButtonCount() {
        return this.mouse.getButtonCount();
    }
    
    public void createMouse() throws LWJGLException {
        lockAWT();
        try {
            this.mouse = new LinuxMouse(getDisplay(), getWindow(), getWindow());
        }
        finally {
            unlockAWT();
        }
    }
    
    public void destroyMouse() {
        this.mouse = null;
        this.updateInputGrab();
    }
    
    public void pollMouse(final IntBuffer coord_buffer, final ByteBuffer buttons) {
        lockAWT();
        try {
            this.mouse.poll(this.grab, coord_buffer, buttons);
        }
        finally {
            unlockAWT();
        }
    }
    
    public void readMouse(final ByteBuffer buffer) {
        lockAWT();
        try {
            this.mouse.read(buffer);
        }
        finally {
            unlockAWT();
        }
    }
    
    public void setCursorPosition(final int x, final int y) {
        lockAWT();
        try {
            this.mouse.setCursorPosition(x, y);
        }
        finally {
            unlockAWT();
        }
    }
    
    private void checkInput() {
        if (this.parent == null) {
            return;
        }
        if (this.parent_focus != this.parent.hasFocus()) {
            this.parent_focus = this.parent.hasFocus();
            if (this.parent_focus) {
                setInputFocusUnsafe(LinuxDisplay.current_window);
            }
            else if (this.xembedded) {
                setInputFocusUnsafe(1L);
            }
        }
    }
    
    private void setFocused(final boolean got_focus, final int focus_detail) {
        if (this.focused == got_focus || focus_detail == 7 || focus_detail == 5 || focus_detail == 6) {
            return;
        }
        this.focused = got_focus;
        if (this.focused) {
            this.acquireInput();
            if (this.parent != null && !this.xembedded) {
                this.parent.setFocusable(false);
            }
        }
        else {
            this.releaseInput();
            if (this.parent != null && !this.xembedded) {
                this.parent.setFocusable(true);
            }
        }
    }
    
    static native long nGetInputFocus(final long p0);
    
    private static void setInputFocusUnsafe(final long window) {
        try {
            setInputFocus(getDisplay(), window, 0L);
            sync(getDisplay(), false);
        }
        catch (final LWJGLException e) {
            LWJGLUtil.log("Got exception while trying to focus: " + e);
        }
    }
    
    private static native void sync(final long p0, final boolean p1) throws LWJGLException;
    
    private void releaseInput() {
        if (isLegacyFullscreen() || this.input_released) {
            return;
        }
        this.input_released = true;
        this.updateInputGrab();
        if (LinuxDisplay.current_window_mode == 2) {
            nIconifyWindow(getDisplay(), getWindow(), getDefaultScreen());
            try {
                if (this.current_displaymode_extension == 10 && this.savedXrandrConfig.length > 0) {
                    AccessController.doPrivileged((PrivilegedAction<Object>)new PrivilegedAction<Object>() {
                        public Object run() {
                            XRandR.setConfiguration(LinuxDisplay.this.savedXrandrConfig);
                            return null;
                        }
                    });
                }
                else {
                    this.switchDisplayModeOnTmpDisplay(this.saved_mode);
                }
                setGammaRampOnTmpDisplay(this.saved_gamma);
            }
            catch (final LWJGLException e) {
                LWJGLUtil.log("Failed to restore saved mode: " + e.getMessage());
            }
        }
    }
    
    private static native void nIconifyWindow(final long p0, final long p1, final int p2);
    
    private void acquireInput() {
        if (isLegacyFullscreen() || !this.input_released) {
            return;
        }
        this.input_released = false;
        this.updateInputGrab();
        if (LinuxDisplay.current_window_mode == 2) {
            try {
                this.switchDisplayModeOnTmpDisplay(this.current_mode);
                setGammaRampOnTmpDisplay(this.current_gamma);
            }
            catch (final LWJGLException e) {
                LWJGLUtil.log("Failed to restore mode: " + e.getMessage());
            }
        }
    }
    
    public void grabMouse(final boolean new_grab) {
        lockAWT();
        try {
            if (new_grab != this.grab) {
                this.grab = new_grab;
                this.updateInputGrab();
                this.mouse.changeGrabbed(this.grab, this.shouldWarpPointer());
            }
        }
        finally {
            unlockAWT();
        }
    }
    
    private boolean shouldWarpPointer() {
        return this.pointer_grabbed && this.shouldGrab();
    }
    
    public int getNativeCursorCapabilities() {
        lockAWT();
        try {
            incDisplay();
            try {
                return nGetNativeCursorCapabilities(getDisplay());
            }
            finally {
                decDisplay();
            }
        }
        catch (final LWJGLException e) {
            throw new RuntimeException(e);
        }
        finally {
            unlockAWT();
        }
    }
    
    private static native int nGetNativeCursorCapabilities(final long p0) throws LWJGLException;
    
    public void setNativeCursor(final Object handle) throws LWJGLException {
        this.current_cursor = getCursorHandle(handle);
        lockAWT();
        try {
            this.updateCursor();
        }
        finally {
            unlockAWT();
        }
    }
    
    public int getMinCursorSize() {
        lockAWT();
        try {
            incDisplay();
            try {
                return nGetMinCursorSize(getDisplay(), getWindow());
            }
            finally {
                decDisplay();
            }
        }
        catch (final LWJGLException e) {
            LWJGLUtil.log("Exception occurred in getMinCursorSize: " + e);
            return 0;
        }
        finally {
            unlockAWT();
        }
    }
    
    private static native int nGetMinCursorSize(final long p0, final long p1);
    
    public int getMaxCursorSize() {
        lockAWT();
        try {
            incDisplay();
            try {
                return nGetMaxCursorSize(getDisplay(), getWindow());
            }
            finally {
                decDisplay();
            }
        }
        catch (final LWJGLException e) {
            LWJGLUtil.log("Exception occurred in getMaxCursorSize: " + e);
            return 0;
        }
        finally {
            unlockAWT();
        }
    }
    
    private static native int nGetMaxCursorSize(final long p0, final long p1);
    
    public void createKeyboard() throws LWJGLException {
        lockAWT();
        try {
            this.keyboard = new LinuxKeyboard(getDisplay(), getWindow());
        }
        finally {
            unlockAWT();
        }
    }
    
    public void destroyKeyboard() {
        lockAWT();
        try {
            this.keyboard.destroy(getDisplay());
            this.keyboard = null;
        }
        finally {
            unlockAWT();
        }
    }
    
    public void pollKeyboard(final ByteBuffer keyDownBuffer) {
        lockAWT();
        try {
            this.keyboard.poll(keyDownBuffer);
        }
        finally {
            unlockAWT();
        }
    }
    
    public void readKeyboard(final ByteBuffer buffer) {
        lockAWT();
        try {
            this.keyboard.read(buffer);
        }
        finally {
            unlockAWT();
        }
    }
    
    private static native long nCreateCursor(final long p0, final int p1, final int p2, final int p3, final int p4, final int p5, final IntBuffer p6, final int p7, final IntBuffer p8, final int p9) throws LWJGLException;
    
    private static long createBlankCursor() {
        return nCreateBlankCursor(getDisplay(), getWindow());
    }
    
    static native long nCreateBlankCursor(final long p0, final long p1);
    
    public Object createCursor(final int width, final int height, final int xHotspot, final int yHotspot, final int numImages, final IntBuffer images, final IntBuffer delays) throws LWJGLException {
        lockAWT();
        try {
            incDisplay();
            try {
                final long cursor = nCreateCursor(getDisplay(), width, height, xHotspot, yHotspot, numImages, images, images.position(), delays, (delays != null) ? delays.position() : -1);
                return cursor;
            }
            catch (final LWJGLException e) {
                decDisplay();
                throw e;
            }
        }
        finally {
            unlockAWT();
        }
    }
    
    private static long getCursorHandle(final Object cursor_handle) {
        return (long)((cursor_handle != null) ? cursor_handle : 0L);
    }
    
    public void destroyCursor(final Object cursorHandle) {
        lockAWT();
        try {
            nDestroyCursor(getDisplay(), getCursorHandle(cursorHandle));
            decDisplay();
        }
        finally {
            unlockAWT();
        }
    }
    
    static native void nDestroyCursor(final long p0, final long p1);
    
    public int getPbufferCapabilities() {
        lockAWT();
        try {
            incDisplay();
            try {
                return nGetPbufferCapabilities(getDisplay(), getDefaultScreen());
            }
            finally {
                decDisplay();
            }
        }
        catch (final LWJGLException e) {
            LWJGLUtil.log("Exception occurred in getPbufferCapabilities: " + e);
            return 0;
        }
        finally {
            unlockAWT();
        }
    }
    
    private static native int nGetPbufferCapabilities(final long p0, final int p1);
    
    public boolean isBufferLost(final PeerInfo handle) {
        return false;
    }
    
    public PeerInfo createPbuffer(final int width, final int height, final PixelFormat pixel_format, final IntBuffer pixelFormatCaps, final IntBuffer pBufferAttribs) throws LWJGLException {
        return new LinuxPbufferPeerInfo(width, height, pixel_format);
    }
    
    public void setPbufferAttrib(final PeerInfo handle, final int attrib, final int value) {
        throw new UnsupportedOperationException();
    }
    
    public void bindTexImageToPbuffer(final PeerInfo handle, final int buffer) {
        throw new UnsupportedOperationException();
    }
    
    public void releaseTexImageFromPbuffer(final PeerInfo handle, final int buffer) {
        throw new UnsupportedOperationException();
    }
    
    private static ByteBuffer convertIcon(final ByteBuffer icon, final int width, final int height) {
        final ByteBuffer icon_rgb = BufferUtils.createByteBuffer(icon.capacity());
        final int depth = 4;
        for (int y = 0; y < height; ++y) {
            for (int x = 0; x < width; ++x) {
                final byte r = icon.get(x * 4 + y * width * 4);
                final byte g = icon.get(x * 4 + y * width * 4 + 1);
                final byte b = icon.get(x * 4 + y * width * 4 + 2);
                icon_rgb.put(x * depth + y * width * depth, b);
                icon_rgb.put(x * depth + y * width * depth + 1, g);
                icon_rgb.put(x * depth + y * width * depth + 2, r);
            }
        }
        return icon_rgb;
    }
    
    private static ByteBuffer convertIconMask(final ByteBuffer icon, final int width, final int height) {
        final ByteBuffer icon_mask = BufferUtils.createByteBuffer(icon.capacity() / 4 / 8);
        final int depth = 4;
        for (int y = 0; y < height; ++y) {
            for (int x = 0; x < width; ++x) {
                final byte a = icon.get(x * 4 + y * width * 4 + 3);
                final int mask_index = x + y * width;
                final int mask_byte_index = mask_index / 8;
                final int mask_bit_index = mask_index % 8;
                final byte bit = (byte)(((a & 0xFF) >= 127) ? 1 : 0);
                final byte new_byte = (byte)((icon_mask.get(mask_byte_index) | bit << mask_bit_index) & 0xFF);
                icon_mask.put(mask_byte_index, new_byte);
            }
        }
        return icon_mask;
    }
    
    public int setIcon(final ByteBuffer[] icons) {
        lockAWT();
        try {
            incDisplay();
            try {
                for (final ByteBuffer icon : icons) {
                    final int size = icon.limit() / 4;
                    final int dimension = (int)Math.sqrt(size);
                    if (dimension > 0) {
                        final ByteBuffer icon_rgb = convertIcon(icon, dimension, dimension);
                        final ByteBuffer icon_mask = convertIconMask(icon, dimension, dimension);
                        nSetWindowIcon(getDisplay(), getWindow(), icon_rgb, icon_rgb.capacity(), icon_mask, icon_mask.capacity(), dimension, dimension);
                        return 1;
                    }
                }
                return 0;
            }
            finally {
                decDisplay();
            }
        }
        catch (final LWJGLException e) {
            LWJGLUtil.log("Failed to set display icon: " + e);
            return 0;
        }
        finally {
            unlockAWT();
        }
    }
    
    private static native void nSetWindowIcon(final long p0, final long p1, final ByteBuffer p2, final int p3, final ByteBuffer p4, final int p5, final int p6, final int p7);
    
    public int getWidth() {
        return Display.getDisplayMode().getWidth();
    }
    
    public int getHeight() {
        return Display.getDisplayMode().getHeight();
    }
    
    public boolean isInsideWindow() {
        return true;
    }
    
    static {
        LinuxDisplay.current_window_mode = 3;
    }
    
    private static final class Compiz
    {
        private static boolean applyFix;
        private static Provider provider;
        
        static void init() {
            if (Display.getPrivilegedBoolean("org.lwjgl.opengl.Window.nocompiz_lfs")) {
                return;
            }
            AccessController.doPrivileged((PrivilegedAction<Object>)new PrivilegedAction<Object>() {
                public Object run() {
                    try {
                        if (!isProcessActive("compiz")) {
                            return null;
                        }
                        Compiz.provider = null;
                        String providerName = null;
                        if (isProcessActive("dbus-daemon")) {
                            providerName = "Dbus";
                            Compiz.provider = new Provider() {
                                private static final String KEY = "/org/freedesktop/compiz/workarounds/allscreens/legacy_fullscreen";
                                
                                public boolean hasLegacyFullscreenSupport() throws LWJGLException {
                                    final List output = run(new String[] { "dbus-send", "--print-reply", "--type=method_call", "--dest=org.freedesktop.compiz", "/org/freedesktop/compiz/workarounds/allscreens/legacy_fullscreen", "org.freedesktop.compiz.get" });
                                    if (output == null || output.size() < 2) {
                                        throw new LWJGLException("Invalid Dbus reply.");
                                    }
                                    String line = output.get(0);
                                    if (!line.startsWith("method return")) {
                                        throw new LWJGLException("Invalid Dbus reply.");
                                    }
                                    line = output.get(1).trim();
                                    if (!line.startsWith("boolean") || line.length() < 12) {
                                        throw new LWJGLException("Invalid Dbus reply.");
                                    }
                                    return "true".equalsIgnoreCase(line.substring("boolean".length() + 1));
                                }
                                
                                public void setLegacyFullscreenSupport(final boolean state) throws LWJGLException {
                                    if (run(new String[] { "dbus-send", "--type=method_call", "--dest=org.freedesktop.compiz", "/org/freedesktop/compiz/workarounds/allscreens/legacy_fullscreen", "org.freedesktop.compiz.set", "boolean:" + Boolean.toString(state) }) == null) {
                                        throw new LWJGLException("Failed to apply Compiz LFS workaround.");
                                    }
                                }
                            };
                        }
                        else {
                            try {
                                Runtime.getRuntime().exec("gconftool");
                                providerName = "gconftool";
                                Compiz.provider = new Provider() {
                                    private static final String KEY = "/apps/compiz/plugins/workarounds/allscreens/options/legacy_fullscreen";
                                    
                                    public boolean hasLegacyFullscreenSupport() throws LWJGLException {
                                        final List output = run(new String[] { "gconftool", "-g", "/apps/compiz/plugins/workarounds/allscreens/options/legacy_fullscreen" });
                                        if (output == null || output.size() == 0) {
                                            throw new LWJGLException("Invalid gconftool reply.");
                                        }
                                        return Boolean.parseBoolean(output.get(0).trim());
                                    }
                                    
                                    public void setLegacyFullscreenSupport(final boolean state) throws LWJGLException {
                                        if (run(new String[] { "gconftool", "-s", "/apps/compiz/plugins/workarounds/allscreens/options/legacy_fullscreen", "-s", Boolean.toString(state), "-t", "bool" }) == null) {
                                            throw new LWJGLException("Failed to apply Compiz LFS workaround.");
                                        }
                                        if (state) {
                                            try {
                                                Thread.sleep(200L);
                                            }
                                            catch (final InterruptedException e) {
                                                e.printStackTrace();
                                            }
                                        }
                                    }
                                };
                            }
                            catch (final IOException ex) {}
                        }
                        if (Compiz.provider != null && !Compiz.provider.hasLegacyFullscreenSupport()) {
                            Compiz.applyFix = true;
                            LWJGLUtil.log("Using " + providerName + " to apply Compiz LFS workaround.");
                        }
                    }
                    catch (final LWJGLException e) {
                        return e;
                    }
                    finally {
                        return null;
                    }
                }
            });
        }
        
        static void setLegacyFullscreenSupport(final boolean enabled) {
            if (!Compiz.applyFix) {
                return;
            }
            AccessController.doPrivileged((PrivilegedAction<Object>)new PrivilegedAction<Object>() {
                public Object run() {
                    try {
                        Compiz.provider.setLegacyFullscreenSupport(enabled);
                    }
                    catch (final LWJGLException e) {
                        LWJGLUtil.log("Failed to change Compiz Legacy Fullscreen Support. Reason: " + e.getMessage());
                    }
                    return null;
                }
            });
        }
        
        private static List<String> run(final String... command) throws LWJGLException {
            final List<String> output = new ArrayList<String>();
            try {
                final Process p = Runtime.getRuntime().exec(command);
                try {
                    final int exitValue = p.waitFor();
                    if (exitValue != 0) {
                        return null;
                    }
                }
                catch (final InterruptedException e) {
                    throw new LWJGLException("Process interrupted.", e);
                }
                final BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
                String line;
                while ((line = br.readLine()) != null) {
                    output.add(line);
                }
                br.close();
            }
            catch (final IOException e2) {
                throw new LWJGLException("Process failed.", e2);
            }
            return output;
        }
        
        private static boolean isProcessActive(final String processName) throws LWJGLException {
            final List<String> output = run("ps", "-C", processName);
            if (output == null) {
                return false;
            }
            for (final String line : output) {
                if (line.contains(processName)) {
                    return true;
                }
            }
            return false;
        }
        
        private interface Provider
        {
            boolean hasLegacyFullscreenSupport() throws LWJGLException;
            
            void setLegacyFullscreenSupport(final boolean p0) throws LWJGLException;
        }
    }
}
