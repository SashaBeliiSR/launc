// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class EXTRescaleNormal
{
    public static final int GL_RESCALE_NORMAL_EXT = 32826;
    
    private EXTRescaleNormal() {
    }
}
