// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class NVPackedDepthStencil
{
    public static final int GL_DEPTH_STENCIL_NV = 34041;
    public static final int GL_UNSIGNED_INT_24_8_NV = 34042;
    
    private NVPackedDepthStencil() {
    }
}
