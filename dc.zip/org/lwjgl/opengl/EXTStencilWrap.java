// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class EXTStencilWrap
{
    public static final int GL_INCR_WRAP_EXT = 34055;
    public static final int GL_DECR_WRAP_EXT = 34056;
    
    private EXTStencilWrap() {
    }
}
