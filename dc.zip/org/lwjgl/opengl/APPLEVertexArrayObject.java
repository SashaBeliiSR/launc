// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import java.nio.IntBuffer;
import org.lwjgl.BufferChecks;

public final class APPLEVertexArrayObject
{
    public static final int GL_VERTEX_ARRAY_BINDING_APPLE = 34229;
    
    private APPLEVertexArrayObject() {
    }
    
    public static void glBindVertexArrayAPPLE(final int array) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glBindVertexArrayAPPLE;
        BufferChecks.checkFunctionAddress(function_pointer);
        nglBindVertexArrayAPPLE(array, function_pointer);
    }
    
    static native void nglBindVertexArrayAPPLE(final int p0, final long p1);
    
    public static void glDeleteVertexArraysAPPLE(final IntBuffer arrays) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glDeleteVertexArraysAPPLE;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(arrays);
        nglDeleteVertexArraysAPPLE(arrays.remaining(), arrays, arrays.position(), function_pointer);
    }
    
    static native void nglDeleteVertexArraysAPPLE(final int p0, final IntBuffer p1, final int p2, final long p3);
    
    public static void glDeleteVertexArraysAPPLE(final int array) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glDeleteVertexArraysAPPLE;
        BufferChecks.checkFunctionAddress(function_pointer);
        nglDeleteVertexArraysAPPLE(1, APIUtil.getBufferInt().put(0, array), 0, function_pointer);
    }
    
    public static void glGenVertexArraysAPPLE(final IntBuffer arrays) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGenVertexArraysAPPLE;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(arrays);
        nglGenVertexArraysAPPLE(arrays.remaining(), arrays, arrays.position(), function_pointer);
    }
    
    static native void nglGenVertexArraysAPPLE(final int p0, final IntBuffer p1, final int p2, final long p3);
    
    public static int glGenVertexArraysAPPLE() {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glGenVertexArraysAPPLE;
        BufferChecks.checkFunctionAddress(function_pointer);
        final IntBuffer arrays = APIUtil.getBufferInt();
        nglGenVertexArraysAPPLE(1, arrays, arrays.position(), function_pointer);
        return arrays.get(0);
    }
    
    public static boolean glIsVertexArrayAPPLE(final int array) {
        final ContextCapabilities caps = GLContext.getCapabilities();
        final long function_pointer = caps.glIsVertexArrayAPPLE;
        BufferChecks.checkFunctionAddress(function_pointer);
        final boolean __result = nglIsVertexArrayAPPLE(array, function_pointer);
        return __result;
    }
    
    static native boolean nglIsVertexArrayAPPLE(final int p0, final long p1);
}
