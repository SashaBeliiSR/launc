// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class NVFogDistance
{
    public static final int GL_FOG_DISTANCE_MODE_NV = 34138;
    public static final int GL_EYE_RADIAL_NV = 34139;
    public static final int GL_EYE_PLANE_ABSOLUTE_NV = 34140;
    
    private NVFogDistance() {
    }
}
