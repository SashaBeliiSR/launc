// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class NVGpuProgram5
{
    public static final int GL_MAX_GEOMETRY_PROGRAM_INVOCATIONS_NV = 36442;
    public static final int GL_MIN_FRAGMENT_INTERPOLATION_OFFSET_NV = 36443;
    public static final int GL_MAX_FRAGMENT_INTERPOLATION_OFFSET_NV = 36444;
    public static final int GL_FRAGMENT_PROGRAM_INTERPOLATION_OFFSET_BITS_NV = 36445;
    
    private NVGpuProgram5() {
    }
}
