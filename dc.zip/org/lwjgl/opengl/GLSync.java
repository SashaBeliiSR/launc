// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import org.lwjgl.PointerWrapperAbstract;

public final class GLSync extends PointerWrapperAbstract
{
    GLSync(final long sync) {
        super(sync);
    }
}
