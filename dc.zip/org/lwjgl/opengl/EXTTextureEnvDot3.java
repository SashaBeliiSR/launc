// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class EXTTextureEnvDot3
{
    public static final int GL_DOT3_RGB_EXT = 34624;
    public static final int GL_DOT3_RGBA_EXT = 34625;
    
    private EXTTextureEnvDot3() {
    }
}
