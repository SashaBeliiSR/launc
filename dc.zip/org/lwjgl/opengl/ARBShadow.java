// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class ARBShadow
{
    public static final int GL_TEXTURE_COMPARE_MODE_ARB = 34892;
    public static final int GL_TEXTURE_COMPARE_FUNC_ARB = 34893;
    public static final int GL_COMPARE_R_TO_TEXTURE_ARB = 34894;
    
    private ARBShadow() {
    }
}
