// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class ARBTextureCompressionRGTC
{
    public static final int GL_COMPRESSED_RED_RGTC1 = 36283;
    public static final int GL_COMPRESSED_SIGNED_RED_RGTC1 = 36284;
    public static final int GL_COMPRESSED_RED_GREEN_RGTC2 = 36285;
    public static final int GL_COMPRESSED_SIGNED_RED_GREEN_RGTC2 = 36286;
    
    private ARBTextureCompressionRGTC() {
    }
}
