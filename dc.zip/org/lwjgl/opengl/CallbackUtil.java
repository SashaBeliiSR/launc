// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import java.util.HashMap;
import java.util.Map;

final class CallbackUtil
{
    private static final Map<Context, Long> contextUserParamsARB;
    private static final Map<Context, Long> contextUserParamsAMD;
    
    private CallbackUtil() {
    }
    
    static long createGlobalRef(final Object obj) {
        return (obj == null) ? 0L : ncreateGlobalRef(obj);
    }
    
    private static native long ncreateGlobalRef(final Object p0);
    
    private static native void deleteGlobalRef(final long p0);
    
    private static void registerContextCallback(final long userParam, final Map<Context, Long> contextUserData) {
        final Context context = Context.getCurrentContext();
        if (context == null) {
            deleteGlobalRef(userParam);
            throw new IllegalStateException("No context is current.");
        }
        final Long userParam_old = contextUserData.remove(context);
        if (userParam_old != null) {
            deleteGlobalRef(userParam_old);
        }
        if (userParam != 0L) {
            contextUserData.put(context, userParam);
        }
    }
    
    static void unregisterCallbacks(final Context context) {
        Long userParam = CallbackUtil.contextUserParamsARB.remove(context);
        if (userParam != null) {
            deleteGlobalRef(userParam);
        }
        userParam = CallbackUtil.contextUserParamsAMD.remove(context);
        if (userParam != null) {
            deleteGlobalRef(userParam);
        }
    }
    
    static native long getDebugOutputCallbackARB();
    
    static void registerContextCallbackARB(final long userParam) {
        registerContextCallback(userParam, CallbackUtil.contextUserParamsARB);
    }
    
    static native long getDebugOutputCallbackAMD();
    
    static void registerContextCallbackAMD(final long userParam) {
        registerContextCallback(userParam, CallbackUtil.contextUserParamsAMD);
    }
    
    static {
        contextUserParamsARB = new HashMap<Context, Long>();
        contextUserParamsAMD = new HashMap<Context, Long>();
    }
}
