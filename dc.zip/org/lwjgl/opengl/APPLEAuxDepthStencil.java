// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class APPLEAuxDepthStencil
{
    public static final int GL_AUX_DEPTH_STENCIL_APPLE = 35348;
    
    private APPLEAuxDepthStencil() {
    }
}
