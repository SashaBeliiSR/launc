// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import java.nio.ByteBuffer;
import java.awt.Canvas;
import org.lwjgl.LWJGLException;

abstract class MacOSXCanvasPeerInfo extends MacOSXPeerInfo
{
    private final AWTSurfaceLock awt_surface;
    
    protected MacOSXCanvasPeerInfo(final PixelFormat pixel_format, final boolean support_pbuffer) throws LWJGLException {
        super(pixel_format, true, true, support_pbuffer, true);
        this.awt_surface = new AWTSurfaceLock();
    }
    
    protected void initHandle(final Canvas component) throws LWJGLException {
        nInitHandle(this.awt_surface.lockAndGetHandle(component), this.getHandle());
    }
    
    private static native void nInitHandle(final ByteBuffer p0, final ByteBuffer p1) throws LWJGLException;
    
    @Override
    protected void doUnlock() throws LWJGLException {
        this.awt_surface.unlock();
    }
}
