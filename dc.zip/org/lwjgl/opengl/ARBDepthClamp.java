// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class ARBDepthClamp
{
    public static final int GL_DEPTH_CLAMP = 34383;
    
    private ARBDepthClamp() {
    }
}
