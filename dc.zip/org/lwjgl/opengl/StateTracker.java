// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

final class StateTracker
{
    private ReferencesStack references_stack;
    private final StateStack attrib_stack;
    private boolean insideBeginEnd;
    
    StateTracker() {
        this.attrib_stack = new StateStack(0);
    }
    
    void init() {
        this.references_stack = new ReferencesStack();
    }
    
    static void setBeginEnd(final ContextCapabilities caps, final boolean inside) {
        caps.tracker.insideBeginEnd = inside;
    }
    
    boolean isBeginEnd() {
        return this.insideBeginEnd;
    }
    
    static void popAttrib(final ContextCapabilities caps) {
        caps.tracker.doPopAttrib();
    }
    
    private void doPopAttrib() {
        this.references_stack.popState(this.attrib_stack.popState());
    }
    
    static void pushAttrib(final ContextCapabilities caps, final int mask) {
        caps.tracker.doPushAttrib(mask);
    }
    
    private void doPushAttrib(final int mask) {
        this.attrib_stack.pushState(mask);
        this.references_stack.pushState();
    }
    
    static ReferencesStack getReferencesStack(final ContextCapabilities caps) {
        return caps.tracker.references_stack;
    }
    
    static void bindBuffer(final ContextCapabilities caps, final int target, final int buffer) {
        final ReferencesStack references_stack = getReferencesStack(caps);
        switch (target) {
            case 34963: {
                references_stack.getReferences().elementArrayBuffer = buffer;
                break;
            }
            case 34962: {
                references_stack.getReferences().arrayBuffer = buffer;
                break;
            }
            case 35051: {
                references_stack.getReferences().pixelPackBuffer = buffer;
                break;
            }
            case 35052: {
                references_stack.getReferences().pixelUnpackBuffer = buffer;
                break;
            }
            case 36671: {
                references_stack.getReferences().indirectBuffer = buffer;
                break;
            }
        }
    }
}
