// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class EXTSharedTexturePalette
{
    public static final int GL_SHARED_TEXTURE_PALETTE_EXT = 33275;
    
    private EXTSharedTexturePalette() {
    }
}
