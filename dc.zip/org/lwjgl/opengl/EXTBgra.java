// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class EXTBgra
{
    public static final int GL_BGR_EXT = 32992;
    public static final int GL_BGRA_EXT = 32993;
    
    private EXTBgra() {
    }
}
