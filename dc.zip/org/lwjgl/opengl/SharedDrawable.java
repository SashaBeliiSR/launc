// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import org.lwjgl.PointerBuffer;
import org.lwjgl.LWJGLException;

public final class SharedDrawable extends AbstractDrawable
{
    public SharedDrawable(final Drawable drawable) throws LWJGLException {
        this.context = ((DrawableLWJGL)drawable).createSharedContext();
    }
    
    @Override
    public Context createSharedContext() {
        throw new UnsupportedOperationException();
    }
}
