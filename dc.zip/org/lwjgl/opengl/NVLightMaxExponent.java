// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class NVLightMaxExponent
{
    public static final int GL_MAX_SHININESS_NV = 34052;
    public static final int GL_MAX_SPOT_EXPONENT_NV = 34053;
    
    private NVLightMaxExponent() {
    }
}
