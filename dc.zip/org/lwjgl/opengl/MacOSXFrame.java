// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

import java.awt.event.WindowEvent;
import java.awt.GraphicsEnvironment;
import java.awt.GraphicsDevice;
import java.awt.event.ComponentEvent;
import java.awt.Insets;
import java.security.PrivilegedActionException;
import java.security.AccessController;
import org.lwjgl.LWJGLException;
import java.awt.Window;
import java.security.PrivilegedExceptionAction;
import java.awt.Component;
import java.awt.Rectangle;
import java.awt.event.ComponentListener;
import java.awt.event.WindowListener;
import java.awt.Frame;

final class MacOSXFrame extends Frame implements WindowListener, ComponentListener
{
    private static final long serialVersionUID = -5823294716668988777L;
    private final MacOSXGLCanvas canvas;
    private boolean close_requested;
    private Rectangle bounds;
    private boolean active;
    private boolean minimized;
    private boolean should_warp_cursor;
    private boolean should_release_cursor;
    
    MacOSXFrame(final DisplayMode mode, final java.awt.DisplayMode requested_mode, final boolean fullscreen, final int x, final int y) throws LWJGLException {
        this.setResizable(false);
        this.addWindowListener(this);
        this.addComponentListener(this);
        (this.canvas = new MacOSXGLCanvas()).setFocusTraversalKeysEnabled(false);
        this.add(this.canvas, "Center");
        final boolean undecorated = Display.getPrivilegedBoolean("org.lwjgl.opengl.Window.undecorated");
        this.setUndecorated(fullscreen || undecorated);
        if (fullscreen) {
            try {
                AccessController.doPrivileged((PrivilegedExceptionAction<Object>)new PrivilegedExceptionAction<Object>() {
                    public Object run() throws Exception {
                        MacOSXFrame.getDevice().setFullScreenWindow(MacOSXFrame.this);
                        MacOSXFrame.getDevice().setDisplayMode(requested_mode);
                        final java.awt.DisplayMode real_mode = MacOSXFrame.getDevice().getDisplayMode();
                        if (requested_mode.getWidth() != real_mode.getWidth() || requested_mode.getHeight() != real_mode.getHeight()) {
                            MacOSXFrame.getDevice().setFullScreenWindow(null);
                            if (MacOSXFrame.this.isDisplayable()) {
                                MacOSXFrame.this.dispose();
                            }
                            throw new LWJGLException("AWT capped mode: requested mode = " + requested_mode.getWidth() + "x" + requested_mode.getHeight() + " but got " + real_mode.getWidth() + " " + real_mode.getHeight());
                        }
                        return null;
                    }
                });
            }
            catch (final PrivilegedActionException e) {
                throw new LWJGLException(e);
            }
        }
        this.pack();
        this.resize(x, y, mode.getWidth(), mode.getHeight());
        this.setVisible(true);
        this.requestFocus();
        this.canvas.requestFocus();
        this.updateBounds();
    }
    
    public void resize(final int x, final int y, final int width, final int height) {
        final Insets insets = this.getInsets();
        this.setBounds(x, y, width + insets.left + insets.right, height + insets.top + insets.bottom);
    }
    
    public Rectangle syncGetBounds() {
        synchronized (this) {
            return this.bounds;
        }
    }
    
    public void componentShown(final ComponentEvent e) {
    }
    
    public void componentHidden(final ComponentEvent e) {
    }
    
    private void updateBounds() {
        synchronized (this) {
            this.bounds = this.getBounds();
        }
    }
    
    public void componentResized(final ComponentEvent e) {
        this.updateBounds();
    }
    
    public void componentMoved(final ComponentEvent e) {
        this.updateBounds();
    }
    
    public static GraphicsDevice getDevice() {
        final GraphicsEnvironment g_env = GraphicsEnvironment.getLocalGraphicsEnvironment();
        final GraphicsDevice device = g_env.getDefaultScreenDevice();
        return device;
    }
    
    public void windowIconified(final WindowEvent e) {
        synchronized (this) {
            this.minimized = true;
        }
    }
    
    public void windowDeiconified(final WindowEvent e) {
        synchronized (this) {
            this.minimized = false;
        }
    }
    
    public void windowOpened(final WindowEvent e) {
    }
    
    public void windowClosed(final WindowEvent e) {
    }
    
    public void windowClosing(final WindowEvent e) {
        synchronized (this) {
            this.close_requested = true;
        }
    }
    
    public void windowDeactivated(final WindowEvent e) {
        synchronized (this) {
            this.active = false;
            this.should_release_cursor = true;
            this.should_warp_cursor = false;
        }
    }
    
    public void windowActivated(final WindowEvent e) {
        synchronized (this) {
            this.active = true;
            this.should_warp_cursor = true;
            this.should_release_cursor = false;
        }
    }
    
    public boolean syncIsCloseRequested() {
        final boolean result;
        synchronized (this) {
            result = this.close_requested;
            this.close_requested = false;
        }
        return result;
    }
    
    public boolean syncIsVisible() {
        synchronized (this) {
            return !this.minimized;
        }
    }
    
    public boolean syncIsActive() {
        synchronized (this) {
            return this.active;
        }
    }
    
    public MacOSXGLCanvas getCanvas() {
        return this.canvas;
    }
    
    public boolean syncShouldReleaseCursor() {
        final boolean result;
        synchronized (this) {
            result = this.should_release_cursor;
            this.should_release_cursor = false;
        }
        return result;
    }
    
    public boolean syncShouldWarpCursor() {
        final boolean result;
        synchronized (this) {
            result = this.should_warp_cursor;
            this.should_warp_cursor = false;
        }
        return result;
    }
}
