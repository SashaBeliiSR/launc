// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class EXTPixelBufferObject extends ARBBufferObject
{
    public static final int GL_PIXEL_PACK_BUFFER_EXT = 35051;
    public static final int GL_PIXEL_UNPACK_BUFFER_EXT = 35052;
    public static final int GL_PIXEL_PACK_BUFFER_BINDING_EXT = 35053;
    public static final int GL_PIXEL_UNPACK_BUFFER_BINDING_EXT = 35055;
    
    private EXTPixelBufferObject() {
    }
}
