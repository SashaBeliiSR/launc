// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class SGISGenerateMipmap
{
    public static final int GL_GENERATE_MIPMAP_SGIS = 33169;
    public static final int GL_GENERATE_MIPMAP_HINT_SGIS = 33170;
    
    private SGISGenerateMipmap() {
    }
}
