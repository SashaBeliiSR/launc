// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class NVCopyDepthToColor
{
    public static final int GL_DEPTH_STENCIL_TO_RGBA_NV = 34926;
    public static final int GL_DEPTH_STENCIL_TO_BGRA_NV = 34927;
    
    private NVCopyDepthToColor() {
    }
}
