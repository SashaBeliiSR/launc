// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class EXTVertexArrayBgra
{
    public static final int GL_BGRA = 32993;
    
    private EXTVertexArrayBgra() {
    }
}
