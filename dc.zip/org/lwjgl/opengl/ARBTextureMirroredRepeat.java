// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class ARBTextureMirroredRepeat
{
    public static final int GL_MIRRORED_REPEAT_ARB = 33648;
    
    private ARBTextureMirroredRepeat() {
    }
}
