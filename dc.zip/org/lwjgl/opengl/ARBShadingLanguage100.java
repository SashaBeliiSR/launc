// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class ARBShadingLanguage100
{
    public static final int GL_SHADING_LANGUAGE_VERSION_ARB = 35724;
    
    private ARBShadingLanguage100() {
    }
}
