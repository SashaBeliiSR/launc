// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class ARBPixelBufferObject extends ARBBufferObject
{
    public static final int GL_PIXEL_PACK_BUFFER_ARB = 35051;
    public static final int GL_PIXEL_UNPACK_BUFFER_ARB = 35052;
    public static final int GL_PIXEL_PACK_BUFFER_BINDING_ARB = 35053;
    public static final int GL_PIXEL_UNPACK_BUFFER_BINDING_ARB = 35055;
    
    private ARBPixelBufferObject() {
    }
}
