// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class ARBDepthTexture
{
    public static final int GL_DEPTH_COMPONENT16_ARB = 33189;
    public static final int GL_DEPTH_COMPONENT24_ARB = 33190;
    public static final int GL_DEPTH_COMPONENT32_ARB = 33191;
    public static final int GL_TEXTURE_DEPTH_SIZE_ARB = 34890;
    public static final int GL_DEPTH_TEXTURE_MODE_ARB = 34891;
    
    private ARBDepthTexture() {
    }
}
