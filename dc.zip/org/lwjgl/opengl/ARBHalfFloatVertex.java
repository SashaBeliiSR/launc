// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opengl;

public final class ARBHalfFloatVertex
{
    public static final int GL_HALF_FLOAT = 5131;
    
    private ARBHalfFloatVertex() {
    }
}
