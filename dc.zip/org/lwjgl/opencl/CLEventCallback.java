// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opencl;

public abstract class CLEventCallback extends CLCallback
{
    protected CLEventCallback() {
        super(CallbackUtil.getEventCallback());
    }
    
    private void handleMessage(final long event_address, final int event_command_exec_status) {
        this.handleMessage(CLContext.getCLEventGlobal(event_address), event_command_exec_status);
    }
    
    protected abstract void handleMessage(final CLEvent p0, final int p1);
}
