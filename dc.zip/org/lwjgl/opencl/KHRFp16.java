// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opencl;

public final class KHRFp16
{
    public static final int CL_DEVICE_HALF_FP_CONFIG = 4147;
    
    private KHRFp16() {
    }
}
