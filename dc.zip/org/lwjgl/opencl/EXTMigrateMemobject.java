// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opencl;

import org.lwjgl.PointerWrapper;
import java.nio.ByteBuffer;
import org.lwjgl.BufferChecks;
import org.lwjgl.PointerBuffer;

public final class EXTMigrateMemobject
{
    public static final int CL_MIGRATE_MEM_OBJECT_HOST_EXT = 1;
    public static final int CL_COMMAND_MIGRATE_MEM_OBJECT_EXT = 16448;
    
    private EXTMigrateMemobject() {
    }
    
    public static int clEnqueueMigrateMemObjectEXT(final CLCommandQueue command_queue, final PointerBuffer mem_objects, final long flags, final PointerBuffer event_wait_list, final PointerBuffer event) {
        final long function_pointer = CLCapabilities.clEnqueueMigrateMemObjectEXT;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkBuffer(mem_objects, 1);
        if (event_wait_list != null) {
            BufferChecks.checkDirect(event_wait_list);
        }
        if (event != null) {
            BufferChecks.checkBuffer(event, 1);
        }
        final int __result = nclEnqueueMigrateMemObjectEXT(command_queue.getPointer(), mem_objects.remaining(), mem_objects.getBuffer(), mem_objects.positionByte(), flags, (event_wait_list == null) ? 0 : event_wait_list.remaining(), (event_wait_list != null) ? event_wait_list.getBuffer() : null, (event_wait_list != null) ? event_wait_list.positionByte() : 0, (event != null) ? event.getBuffer() : null, (event != null) ? event.positionByte() : 0, function_pointer);
        if (__result == 0) {
            command_queue.registerCLEvent(event);
        }
        return __result;
    }
    
    static native int nclEnqueueMigrateMemObjectEXT(final long p0, final int p1, final ByteBuffer p2, final int p3, final long p4, final int p5, final ByteBuffer p6, final int p7, final ByteBuffer p8, final int p9, final long p10);
    
    public static int clEnqueueMigrateMemObjectEXT(final CLCommandQueue command_queue, final CLMem mem_object, final long flags, final PointerBuffer event_wait_list, final PointerBuffer event) {
        final long function_pointer = CLCapabilities.clEnqueueMigrateMemObjectEXT;
        BufferChecks.checkFunctionAddress(function_pointer);
        if (event_wait_list != null) {
            BufferChecks.checkDirect(event_wait_list);
        }
        if (event != null) {
            BufferChecks.checkBuffer(event, 1);
        }
        final int __result = nclEnqueueMigrateMemObjectEXT(command_queue.getPointer(), 1, APIUtil.getBufferPointer().put(0, mem_object).getBuffer(), 0, flags, (event_wait_list == null) ? 0 : event_wait_list.remaining(), (event_wait_list != null) ? event_wait_list.getBuffer() : null, (event_wait_list != null) ? event_wait_list.positionByte() : 0, (event != null) ? event.getBuffer() : null, (event != null) ? event.positionByte() : 0, function_pointer);
        if (__result == 0) {
            command_queue.registerCLEvent(event);
        }
        return __result;
    }
}
