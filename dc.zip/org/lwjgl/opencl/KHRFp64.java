// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opencl;

public final class KHRFp64
{
    public static final int CL_DEVICE_DOUBLE_FP_CONFIG = 4146;
    
    private KHRFp64() {
    }
}
