// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opencl;

import java.util.HashMap;
import java.util.Map;

final class CallbackUtil
{
    private static final Map<CLContext, Long> contextUserData;
    
    private CallbackUtil() {
    }
    
    static long createGlobalRef(final Object obj) {
        return (obj == null) ? 0L : ncreateGlobalRef(obj);
    }
    
    private static native long ncreateGlobalRef(final Object p0);
    
    private static native void deleteGlobalRef(final long p0);
    
    static void checkCallback(final int errcode, final long user_data) {
        if (errcode != 0 && user_data != 0L) {
            deleteGlobalRef(user_data);
        }
    }
    
    static native long getContextCallback();
    
    static void registerCallback(final CLContext context, final long user_data) {
        if (context.getPointerUnsafe() == 0L) {
            if (user_data != 0L) {
                deleteGlobalRef(user_data);
            }
            return;
        }
        if (user_data != 0L) {
            CallbackUtil.contextUserData.put(context, user_data);
        }
    }
    
    static void unregisterCallback(final CLContext context) {
        if (context.release() > 0) {
            return;
        }
        final Long user_data = CallbackUtil.contextUserData.remove(context);
        if (user_data != null) {
            deleteGlobalRef(user_data);
        }
    }
    
    static native long getMemObjectDestructorCallback();
    
    static native long getBuildProgramCallback();
    
    static native long getNativeKernelCallback();
    
    static native long getEventCallback();
    
    static native long getLogMessageToSystemLogAPPLE();
    
    static native long getLogMessageToStdoutAPPLE();
    
    static native long getLogMessageToStderrAPPLE();
    
    static {
        contextUserData = new HashMap<CLContext, Long>();
    }
}
