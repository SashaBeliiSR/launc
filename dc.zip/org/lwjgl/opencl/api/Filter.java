// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opencl.api;

public interface Filter<T>
{
    boolean accept(final T p0);
}
