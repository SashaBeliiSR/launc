// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opencl;

public abstract class CLMemObjectDestructorCallback extends CLCallback
{
    protected CLMemObjectDestructorCallback() {
        super(CallbackUtil.getMemObjectDestructorCallback());
    }
    
    protected abstract void handleMessage(final long p0);
}
