// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opencl;

public final class AMDDeviceAttributeQuery
{
    public static final int CL_DEVICE_PROFILING_TIMER_OFFSET_AMD = 16438;
    
    private AMDDeviceAttributeQuery() {
    }
}
