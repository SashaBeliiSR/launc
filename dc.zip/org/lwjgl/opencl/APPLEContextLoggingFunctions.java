// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opencl;

import org.lwjgl.BufferChecks;
import java.nio.ByteBuffer;

final class APPLEContextLoggingFunctions
{
    private APPLEContextLoggingFunctions() {
    }
    
    static void clLogMessagesToSystemLogAPPLE(final ByteBuffer errstr, final ByteBuffer private_info, final ByteBuffer user_data) {
        final long function_pointer = CLCapabilities.clLogMessagesToSystemLogAPPLE;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(errstr);
        BufferChecks.checkDirect(private_info);
        BufferChecks.checkDirect(user_data);
        nclLogMessagesToSystemLogAPPLE(errstr, errstr.position(), private_info, private_info.position(), private_info.remaining(), user_data, user_data.position(), function_pointer);
    }
    
    static native void nclLogMessagesToSystemLogAPPLE(final ByteBuffer p0, final int p1, final ByteBuffer p2, final int p3, final long p4, final ByteBuffer p5, final int p6, final long p7);
    
    static void clLogMessagesToStdoutAPPLE(final ByteBuffer errstr, final ByteBuffer private_info, final ByteBuffer user_data) {
        final long function_pointer = CLCapabilities.clLogMessagesToStdoutAPPLE;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(errstr);
        BufferChecks.checkDirect(private_info);
        BufferChecks.checkDirect(user_data);
        nclLogMessagesToStdoutAPPLE(errstr, errstr.position(), private_info, private_info.position(), private_info.remaining(), user_data, user_data.position(), function_pointer);
    }
    
    static native void nclLogMessagesToStdoutAPPLE(final ByteBuffer p0, final int p1, final ByteBuffer p2, final int p3, final long p4, final ByteBuffer p5, final int p6, final long p7);
    
    static void clLogMessagesToStderrAPPLE(final ByteBuffer errstr, final ByteBuffer private_info, final ByteBuffer user_data) {
        final long function_pointer = CLCapabilities.clLogMessagesToStderrAPPLE;
        BufferChecks.checkFunctionAddress(function_pointer);
        BufferChecks.checkDirect(errstr);
        BufferChecks.checkDirect(private_info);
        BufferChecks.checkDirect(user_data);
        nclLogMessagesToStderrAPPLE(errstr, errstr.position(), private_info, private_info.position(), private_info.remaining(), user_data, user_data.position(), function_pointer);
    }
    
    static native void nclLogMessagesToStderrAPPLE(final ByteBuffer p0, final int p1, final ByteBuffer p2, final int p3, final long p4, final ByteBuffer p5, final int p6, final long p7);
}
