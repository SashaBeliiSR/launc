// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opencl;

import org.lwjgl.PointerWrapperAbstract;

final class CLFunctionAddress extends PointerWrapperAbstract
{
    CLFunctionAddress(final long pointer) {
        super(pointer);
    }
}
