// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opencl;

import org.lwjgl.PointerWrapperAbstract;

abstract class CLCallback extends PointerWrapperAbstract
{
    private final boolean custom;
    
    protected CLCallback(final long pointer) {
        this(pointer, false);
    }
    
    protected CLCallback(final long pointer, final boolean custom) {
        super(pointer);
        this.custom = custom;
    }
    
    final boolean isCustom() {
        return this.custom;
    }
}
