// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opencl;

import java.nio.ByteBuffer;
import org.lwjgl.BufferChecks;
import java.nio.IntBuffer;
import org.lwjgl.PointerBuffer;

public final class KHRICD
{
    public static final int CL_PLATFORM_ICD_SUFFIX_KHR = 2336;
    public static final int CL_PLATFORM_NOT_FOUND_KHR = -1001;
    
    private KHRICD() {
    }
    
    public static int clIcdGetPlatformIDsKHR(final PointerBuffer platforms, final IntBuffer num_platforms) {
        final long function_pointer = CLCapabilities.clIcdGetPlatformIDsKHR;
        BufferChecks.checkFunctionAddress(function_pointer);
        if (platforms != null) {
            BufferChecks.checkDirect(platforms);
        }
        if (num_platforms != null) {
            BufferChecks.checkBuffer(num_platforms, 1);
        }
        final int __result = nclIcdGetPlatformIDsKHR((platforms == null) ? 0 : platforms.remaining(), (platforms != null) ? platforms.getBuffer() : null, (platforms != null) ? platforms.positionByte() : 0, num_platforms, (num_platforms != null) ? num_platforms.position() : 0, function_pointer);
        return __result;
    }
    
    static native int nclIcdGetPlatformIDsKHR(final int p0, final ByteBuffer p1, final int p2, final IntBuffer p3, final int p4, final long p5);
}
