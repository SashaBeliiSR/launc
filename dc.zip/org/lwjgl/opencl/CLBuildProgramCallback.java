// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opencl;

public abstract class CLBuildProgramCallback extends CLCallback
{
    protected CLBuildProgramCallback() {
        super(CallbackUtil.getBuildProgramCallback());
    }
    
    private void handleMessage(final long program_address) {
        this.handleMessage(CLContext.getCLProgramGlobal(program_address));
    }
    
    protected abstract void handleMessage(final CLProgram p0);
}
