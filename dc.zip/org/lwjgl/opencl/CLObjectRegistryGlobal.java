// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.opencl;

final class CLObjectRegistryGlobal<T extends CLObjectChild> extends CLObjectRegistry<T>
{
    private final FastLongMap<T> globalRegistry;
    
    CLObjectRegistryGlobal(final FastLongMap<T> globalRegistry) {
        this.globalRegistry = globalRegistry;
    }
    
    @Override
    void registerObject(final T object) {
        super.registerObject(object);
        this.globalRegistry.put(object.getPointer(), object);
    }
    
    @Override
    void unregisterObject(final T object) {
        super.unregisterObject(object);
        this.globalRegistry.remove(object.getPointerUnsafe());
    }
}
