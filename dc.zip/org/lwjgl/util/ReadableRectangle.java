// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.util;

public interface ReadableRectangle extends ReadableDimension, ReadablePoint
{
    void getBounds(final WritableRectangle p0);
}
