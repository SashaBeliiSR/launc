// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.util.vector;

public interface ReadableVector3f extends ReadableVector2f
{
    float getZ();
}
