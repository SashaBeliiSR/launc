// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.util.vector;

public interface WritableVector2f
{
    void setX(final float p0);
    
    void setY(final float p0);
    
    void set(final float p0, final float p1);
}
