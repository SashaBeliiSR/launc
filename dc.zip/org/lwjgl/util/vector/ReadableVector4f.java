// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.util.vector;

public interface ReadableVector4f extends ReadableVector3f
{
    float getW();
}
