// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.util;

public interface Renderable
{
    void render();
}
