// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.util;

public interface WritableDimension
{
    void setSize(final int p0, final int p1);
    
    void setSize(final ReadableDimension p0);
    
    void setHeight(final int p0);
    
    void setWidth(final int p0);
}
