// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.util;

public interface WritablePoint
{
    void setLocation(final int p0, final int p1);
    
    void setLocation(final ReadablePoint p0);
    
    void setX(final int p0);
    
    void setY(final int p0);
}
