// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.util;

public interface ReadableDimension
{
    int getWidth();
    
    int getHeight();
    
    void getSize(final WritableDimension p0);
}
