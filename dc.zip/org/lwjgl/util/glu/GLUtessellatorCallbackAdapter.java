// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.util.glu;

public class GLUtessellatorCallbackAdapter implements GLUtessellatorCallback
{
    public void begin(final int type) {
    }
    
    public void edgeFlag(final boolean boundaryEdge) {
    }
    
    public void vertex(final Object vertexData) {
    }
    
    public void end() {
    }
    
    public void error(final int errnum) {
    }
    
    public void combine(final double[] coords, final Object[] data, final float[] weight, final Object[] outData) {
    }
    
    public void beginData(final int type, final Object polygonData) {
    }
    
    public void edgeFlagData(final boolean boundaryEdge, final Object polygonData) {
    }
    
    public void vertexData(final Object vertexData, final Object polygonData) {
    }
    
    public void endData(final Object polygonData) {
    }
    
    public void errorData(final int errnum, final Object polygonData) {
    }
    
    public void combineData(final double[] coords, final Object[] data, final float[] weight, final Object[] outData, final Object polygonData) {
    }
}
