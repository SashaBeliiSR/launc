// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.util.glu.tessellation;

class CachedVertex
{
    public double[] coords;
    public Object data;
    
    CachedVertex() {
        this.coords = new double[3];
    }
}
