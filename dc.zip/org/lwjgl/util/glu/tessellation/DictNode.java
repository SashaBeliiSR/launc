// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.util.glu.tessellation;

class DictNode
{
    Object key;
    DictNode next;
    DictNode prev;
}
