// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl.util.glu.tessellation;

class TessState
{
    public static final int T_DORMANT = 0;
    public static final int T_IN_POLYGON = 1;
    public static final int T_IN_CONTOUR = 2;
}
