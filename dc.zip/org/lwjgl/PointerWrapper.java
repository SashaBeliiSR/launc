// 
// Decompiled by Procyon v0.6.0
// 

package org.lwjgl;

public interface PointerWrapper
{
    long getPointer();
}
